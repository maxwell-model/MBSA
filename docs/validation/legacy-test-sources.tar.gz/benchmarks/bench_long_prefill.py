#!/usr/bin/env python3
"""Whole-sequence prefill: MBSA chunked prefill vs dense causal GQA (FA4).

Mirrors docs/images/maxwell-block-sparse-attention-performance.png. For a
sequence of L tokens, dense GQA runs one causal FlashAttention-4 call over
Q=KV=L. MBSA runs the CuTe DSL pipeline chunk by chunk (Q=8192 per chunk,
KV = all tokens up to the chunk end); its time is the sum of chunk medians.
Chunk c has the same shape for every L, so chunks are measured once.
"""

from __future__ import annotations

import argparse
import gc
import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
import torch

from mbsa import prepare_cutedsl_pipeline, reference_pipeline

CHUNK = 8192


def timed(fn, flush, warmups, samples):
    for _ in range(warmups):
        fn()
    torch.cuda.synchronize()
    values = []
    for _ in range(samples):
        flush.add_(1)
        start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        fn()
        end.record()
        end.synchronize()
        values.append(start.elapsed_time(end))
    return statistics.median(values), values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lengths", default="32768,65536,131072,262144,524288,1048576")
    parser.add_argument("--warmups", type=int, default=2)
    parser.add_argument("--samples", type=int, default=5)
    parser.add_argument("--dense-samples", type=int, default=3)
    parser.add_argument("--skip-dense", action="store_true")
    parser.add_argument("--seed", type=int, default=17)
    args = parser.parse_args()
    lengths = [int(x) for x in args.lengths.split(",")]
    if any(n % CHUNK for n in lengths):
        parser.error("lengths must be multiples of 8192")
    longest = max(lengths)
    torch.manual_seed(args.seed)

    def rand(*shape):
        return torch.randn(*shape, device="cuda", dtype=torch.bfloat16)

    q, iq = rand(longest, 32, 128), rand(longest, 4, 128)
    k, v = rand(longest, 4, 128), rand(longest, 4, 128)
    ik = rand(longest // 128, 1, 128, 128)
    flush = torch.empty(256 << 20, dtype=torch.uint8, device="cuda")
    result = {
        "device": torch.cuda.get_device_name(),
        "capability": torch.cuda.get_device_capability(),
        "chunk": CHUNK,
        "heads": {"q": 32, "kv": 4, "dim": 128},
        "mbsa_chunks": [],
        "dense": [],
    }

    # Precision probe: final 16 queries of the longest chunk vs the oracle.
    for c in range(longest // CHUNK):
        kv = (c + 1) * CHUNK
        qs = slice(c * CHUNK, kv)
        pipeline = prepare_cutedsl_pipeline(
            iq[qs], ik[: kv // 128], q[qs], k[:kv], v[:kv]
        )
        median, samples = timed(pipeline.run, flush, args.warmups, args.samples)
        entry = {"chunk": c, "kv": kv, "median_ms": median, "samples_ms": samples}
        if c in (0, longest // CHUNK - 1):
            out, lse, route = pipeline.run()
            probe = slice(CHUNK - 16, CHUNK)
            eo, el, er = reference_pipeline(
                iq[qs][probe], ik[: kv // 128].reshape(-1, 1, 128), q[qs][probe],
                k[:kv], v[:kv], query_offset=kv - 16,
            )
            entry["route_exact"] = bool(
                torch.equal(route[:, probe].sort(-1).values, er.sort(-1).values)
            )
            entry["output_max_abs"] = float((out[probe].float() - eo.float()).abs().max())
            entry["lse_max_abs"] = float((lse[probe] - el).abs().max())
        result["mbsa_chunks"].append(entry)
        print(json.dumps({k_: v_ for k_, v_ in entry.items() if k_ != "samples_ms"}), flush=True)
        del pipeline
        gc.collect()
        torch.cuda.empty_cache()

    if not args.skip_dense:
        from flash_attn.cute import flash_attn_func

        # Dense correctness against PyTorch SDPA on a short causal prefix.
        n = 4096
        ref = torch.nn.functional.scaled_dot_product_attention(
            q[:n].transpose(0, 1)[None], k[:n].transpose(0, 1)[None],
            v[:n].transpose(0, 1)[None], is_causal=True, enable_gqa=True,
        )[0].transpose(0, 1)
        got = flash_attn_func(q[None, :n], k[None, :n], v[None, :n], causal=True)
        got = got[0] if isinstance(got, tuple) else got
        result["dense_check_max_abs"] = float((got[0].float() - ref.float()).abs().max())
        for n in lengths:
            fn = lambda: flash_attn_func(q[None, :n], k[None, :n], v[None, :n], causal=True)
            median, samples = timed(fn, flush, 1, args.dense_samples)
            result["dense"].append({"length": n, "median_ms": median, "samples_ms": samples})
            print(json.dumps({"dense_length": n, "median_ms": median}), flush=True)

    chunk_ms = [c["median_ms"] for c in result["mbsa_chunks"]]
    dense = {d["length"]: d["median_ms"] for d in result["dense"]}
    result["summary"] = [
        {
            "length": n,
            "mbsa_ms": sum(chunk_ms[: n // CHUNK]),
            "dense_gqa_ms": dense.get(n),
            "speedup": dense[n] / sum(chunk_ms[: n // CHUNK]) if n in dense else None,
        }
        for n in lengths
    ]
    print("RESULT_JSON=" + json.dumps(result), flush=True)


if __name__ == "__main__":
    main()

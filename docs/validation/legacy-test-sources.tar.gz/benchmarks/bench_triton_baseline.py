#!/usr/bin/env python3
"""Check Triton against the Maxwell Block Sparse Attention Python reference and time its stages."""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import torch

from mbsa import reference_pipeline, triton_pipeline
from mbsa.triton_backend import (
    build_kv_grouped_schedule,
    dynamic_partials,
    fixed_attention,
    merge_states,
    route_topk,
    sparse_attention,
)


INDEX_HEADS = 4
QUERY_HEADS = 32
DIM = 128


def make_inputs(q_tokens: int, kv_tokens: int, seed: int):
    generator = torch.Generator(device="cuda").manual_seed(seed)

    def randn(shape):
        return torch.randn(shape, device="cuda", dtype=torch.bfloat16, generator=generator)

    return (
        randn((q_tokens, INDEX_HEADS, DIM)),
        randn((kv_tokens, 1, DIM)),
        randn((q_tokens, QUERY_HEADS, DIM)),
        randn((kv_tokens, INDEX_HEADS, DIM)),
        randn((kv_tokens, INDEX_HEADS, DIM)),
    )


def median_ms(function, warmups: int, samples: int) -> float:
    for _ in range(warmups):
        function()
    torch.cuda.synchronize()
    measurements = []
    for _ in range(samples):
        start = torch.cuda.Event(enable_timing=True)
        end = torch.cuda.Event(enable_timing=True)
        start.record()
        function()
        end.record()
        end.synchronize()
        measurements.append(start.elapsed_time(end))
    return statistics.median(measurements)


def correctness(seed: int):
    """Cover long routing, partial query/KV tiles, and empty dynamic support."""
    results = []
    for q_tokens, kv_tokens in ((128, 8192), (17, 4113), (128, 128)):
        inputs = make_inputs(q_tokens, kv_tokens, seed)
        output, lse, route = triton_pipeline(*inputs)
        expected_output, expected_lse, expected_route = reference_pipeline(*inputs)
        output_error = (output.float() - expected_output.float()).abs().max().item()
        lse_error = (lse.float() - expected_lse.float()).abs().max().item()
        route_exact = torch.equal(route.sort(-1).values, expected_route.sort(-1).values)
        result = {
            "q": q_tokens,
            "kv": kv_tokens,
            "route_exact": route_exact,
            "output_max_abs": output_error,
            "lse_max_abs": lse_error,
            "passed": route_exact and output_error <= 0.03 and lse_error <= 0.01,
        }
        results.append(result)
    return {"passed": all(result["passed"] for result in results), "cases": results}


def benchmark_case(kv_tokens: int, warmups: int, samples: int, seed: int, max_queries: int):
    q_tokens = min(max_queries, kv_tokens)
    if (kv_tokens - q_tokens) % 128:
        raise ValueError("Triton fixed attention requires a block-aligned query offset")
    index_q, index_k, q, k, v = make_inputs(q_tokens, kv_tokens, seed)
    route, _ = route_topk(index_q, index_k)
    schedule = build_kv_grouped_schedule(route, kv_tokens)
    fixed_state = fixed_attention(q, k, v)
    dynamic_state = dynamic_partials(q, k, v, route, schedule)
    fixed_stream = torch.cuda.Stream()
    return {
        "kv": kv_tokens,
        "q": q_tokens,
        "router_ms": median_ms(lambda: route_topk(index_q, index_k), warmups, samples),
        "schedule_ms": median_ms(
            lambda: build_kv_grouped_schedule(route, kv_tokens), warmups, samples
        ),
        "fixed_ms": median_ms(lambda: fixed_attention(q, k, v), warmups, samples),
        "dynamic_ms": median_ms(
            lambda: dynamic_partials(q, k, v, route, schedule), warmups, samples
        ),
        "merge_ms": median_ms(
            lambda: merge_states(*fixed_state, *dynamic_state, k.shape[1]), warmups, samples
        ),
        "attention_ms": median_ms(
            lambda: sparse_attention(q, k, v, route, schedule=schedule), warmups, samples
        ),
        "e2e_ms": median_ms(
            lambda: triton_pipeline(index_q, index_k, q, k, v, fixed_stream=fixed_stream),
            warmups,
            samples,
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kv", default="8192,32768,65536")
    parser.add_argument("--q", type=int, default=8192, help="Maximum query tokens per benchmark")
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--samples", type=int, default=11)
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--skip-correctness", action="store_true")
    args = parser.parse_args()
    kv_lengths = [int(value) for value in args.kv.split(",")]
    if args.q <= 0 or args.samples <= 0 or args.warmups < 0 or any(kv <= 0 for kv in kv_lengths):
        parser.error("q, kv, and samples must be positive; warmups must be nonnegative")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required")
    payload = {
        "kind": "triton_baseline",
        "device": torch.cuda.get_device_name(0),
        "torch": torch.__version__,
        "correctness": None if args.skip_correctness else correctness(args.seed),
        "results": [],
    }
    print(json.dumps({key: value for key, value in payload.items() if key != "results"}), flush=True)
    if payload["correctness"] is not None and not payload["correctness"]["passed"]:
        raise RuntimeError("Triton precision check failed")
    for kv_tokens in kv_lengths:
        result = benchmark_case(kv_tokens, args.warmups, args.samples, args.seed, args.q)
        payload["results"].append(result)
        print(json.dumps(result), flush=True)
    print("RESULT_JSON=" + json.dumps(payload), flush=True)


if __name__ == "__main__":
    main()

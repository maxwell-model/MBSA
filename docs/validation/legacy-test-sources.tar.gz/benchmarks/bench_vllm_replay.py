#!/usr/bin/env python3
"""Replay observed vLLM prefill geometries under a shared timing policy.

Inputs are deterministic synthetic BF16 values in the real interleaved cache
layout. This measures kernels and hot adapter overhead, not model throughput.
"""

import argparse
import importlib
import importlib.util
import json
import hashlib
from pathlib import Path
import statistics
import time

import torch


def native_modules():
    for stem, prefix in (
        ("maxwell_moe", "MaxwellMoe"),
        ("maxwell_v1", "MaxwellV1"),
        ("compass", "Compass"),
    ):
        name = f"vllm.model_executor.layers.{stem}_bsa"
        if importlib.util.find_spec(name) is not None:
            attention = importlib.import_module(name)
            indexer = importlib.import_module(name + "_indexer")
            return (
                attention,
                getattr(attention, prefix + "BsaSparseGqa"),
                getattr(indexer, prefix + "BsaIndexer"),
            )
    raise RuntimeError("No supported native vLLM sparse Attention module")


def measure(fn, samples):
    gpu, wall = [], []
    for _ in range(samples):
        torch.cuda.synchronize()
        begin, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
        started = time.perf_counter()
        begin.record()
        fn()
        end.record()
        end.synchronize()
        wall.append((time.perf_counter() - started) * 1000)
        gpu.append(begin.elapsed_time(end))
    return {
        "cuda_event_median_ms": statistics.median(gpu),
        "wall_median_ms": statistics.median(wall),
        "cuda_event_samples_ms": gpu,
        "wall_samples_ms": wall,
    }


def run_case(lengths, native, attention_cls, indexer_cls, args):
    torch.manual_seed(17)
    device = torch.device("cuda", 0)
    counts = [(kn + 127) // 128 for _, kn in lengths]
    pages, total_q = sum(counts), sum(qn for qn, _ in lengths)
    rand = lambda shape: torch.randn(shape, device=device, dtype=torch.bfloat16)
    q, iq = rand((total_q, 32, 128)), rand((total_q, 4, 128))
    pool = rand((pages, 128, 4, 2, 128))
    k, v = pool[..., 0, :], pool[..., 1, :]
    ik = rand((pages, 1, 128, 128))
    mapping = torch.arange(pages - 1, -1, -1, device=device, dtype=torch.int32)
    table_width = ((max(counts) + 127) // 128) * 128
    table = torch.zeros((len(lengths), table_width), device=device, dtype=torch.int32)
    start = 0
    for slot, count in enumerate(counts):
        table[slot, :count].copy_(mapping[start : start + count])
        start += count
    q_prefix, k_prefix = [0], [0]
    for qn, kn in lengths:
        q_prefix.append(q_prefix[-1] + qn)
        k_prefix.append(k_prefix[-1] + kn)
    cuda_int = lambda values: torch.tensor(values, device=device, dtype=torch.int32)
    cu_q, cu_k = cuda_int(q_prefix), cuda_int(k_prefix)
    seq = cuda_int([kn for _, kn in lengths])
    offsets = cuda_int([kn - qn for qn, kn in lengths])
    indexer = indexer_cls(
        num_index_heads=4,
        num_kv_heads=4,
        head_dim=128,
        block_size=128,
        shared_route=False,
        score_reduce="max",
        init_blocks=8,
        local_blocks=8,
    )
    indexer._k_cache = ik
    attention = attention_cls(
        num_qo_heads=32,
        num_kv_heads=4,
        head_dim=128,
        block_size=128,
        topk=32,
        shared_route=False,
    )
    plan = indexer.build_plan(
        qo_lens=torch.tensor([qn for qn, _ in lengths], dtype=torch.int32),
        kv_lens=torch.tensor([kn for _, kn in lengths], dtype=torch.int32),
        qo_offset=torch.tensor([kn - qn for qn, kn in lengths], dtype=torch.int32),
    )
    visible = torch.cat(
        [
            torch.arange(kn - qn, kn, device=device, dtype=torch.int32).div(
                128, rounding_mode="floor"
            )
            + 1
            for qn, kn in lengths
        ]
    )
    legacy_out, unified_out, mbsa_out = (torch.empty_like(q) for _ in range(3))
    common = dict(
        index_q=iq,
        index_k_cache=indexer.decode_k_cache(),
        index_plan=plan,
        index_page_indices=mapping,
        page_table=table,
        seq_lens=seq,
        request_lens=list(lengths),
        cu_seqlens_q=cu_q,
        cu_seqlens_k=cu_k,
        prefix_lens=offsets,
    )

    def legacy():
        score = indexer.max_scores(iq, plan=plan, kv_indices=mapping)
        route = indexer.select(
            score, num_valid_pages=max(counts), topk=32, per_query_valid=visible
        )
        return attention.prefill(
            q,
            k,
            v,
            route,
            cu_seqlens_q=cu_q,
            cu_seqlens_k=cu_k,
            seq_lens=seq,
            page_table=table,
            max_seqlen_q=max(qn for qn, _ in lengths),
            max_seqlen_k=max(kn for _, kn in lengths),
            total_rows=pages,
            total_k=k_prefix[-1],
            softmax_scale=128**-0.5,
            out=legacy_out,
        )

    def unified():
        return attention.prefill_unified(q, k, v, **common, out=unified_out)

    functions = {"legacy_sparse_gqa": legacy}
    legacy()
    partial_dtype = getattr(attention, "prefill_partial_dtype", attention.partial_dtype)
    result = {
        "requests": lengths,
        "native_module": native.__name__,
        "partial_dtype": str(partial_dtype),
        "key_stride": list(k.stride()),
        "value_offset_elements": (v.data_ptr() - k.data_ptr()) // k.element_size(),
    }
    if unified() is not None:
        torch.testing.assert_close(unified_out, legacy_out, atol=0.04, rtol=0.04)
        functions["native_unified"] = unified
        result["unified_max_abs_error"] = (
            (unified_out.float() - legacy_out.float()).abs().max().item()
        )
    else:
        result["native_unified"] = {"status": "refused"}
    if not args.native_only:
        from mbsa.vllm import PagedPrefill

        adapter = PagedPrefill(use_graphs=args.graph_adapter)

        def mbsa():
            return adapter(
                q,
                k,
                v,
                **common,
                out=mbsa_out,
                partial_dtype=partial_dtype,
            )

        mbsa()
        torch.testing.assert_close(mbsa_out, legacy_out, atol=0.04, rtol=0.04)
        result["mbsa_max_abs_error"] = (
            (mbsa_out.float() - legacy_out.float()).abs().max().item()
        )
        functions[
            "mbsa_graph_adapter" if args.graph_adapter else "mbsa_eager_adapter"
        ] = mbsa
        pipeline = next(iter(adapter.plans.values()))
        functions["mbsa_prepared_plan"] = lambda: pipeline.run()[0]
    for _ in range(args.warmups):
        for fn in functions.values():
            fn()
    # All variants keep warm L2, use the same samples, inputs and cache layout.
    # Alternate submission order; compilation and cold preparation are excluded.
    measurements = {
        name: {"cuda_event_samples_ms": [], "wall_samples_ms": []} for name in functions
    }
    for sample in range(args.samples):
        order = list(functions.items())
        if sample % 2:
            order.reverse()
        for name, fn in order:
            values = measure(fn, 1)
            for field in measurements[name]:
                measurements[name][field].extend(values[field])
    for name, values in measurements.items():
        values["cuda_event_median_ms"] = statistics.median(
            values["cuda_event_samples_ms"]
        )
        values["wall_median_ms"] = statistics.median(values["wall_samples_ms"])
        result[name] = values
    if args.graphs:
        if "native_unified" in functions:
            stream = torch.cuda.Stream()
            stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                unified()
            stream.synchronize()
            native_graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(native_graph, stream=stream):
                unified()
            native_graph.replay()
            torch.testing.assert_close(unified_out, legacy_out, atol=0.04, rtol=0.04)
            functions["native_unified_graph"] = native_graph.replay
        if not args.native_only:
            pipeline.plan.capture_mega_graph()
            pipeline.plan.run_mega()
            torch.testing.assert_close(
                pipeline.plan.attention.out, legacy_out, atol=0.04, rtol=0.04
            )
            functions["mbsa_prepared_graph"] = pipeline.plan.run_mega

        graph_functions = [
            (name, fn) for name, fn in functions.items() if name.endswith("_graph")
        ]
        for _ in range(args.warmups):
            for _, fn in graph_functions:
                fn()
        for name, _ in graph_functions:
            result[name] = {"cuda_event_samples_ms": [], "wall_samples_ms": []}
        for sample in range(args.samples):
            order = (
                graph_functions if sample % 2 == 0 else list(reversed(graph_functions))
            )
            for name, fn in order:
                values = measure(fn, 1)
                for field in result[name]:
                    result[name][field].extend(values[field])
        for name, _ in graph_functions:
            for field in ("cuda_event", "wall"):
                result[name][f"{field}_median_ms"] = statistics.median(
                    result[name][f"{field}_samples_ms"]
                )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=9)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--native-only", action="store_true")
    parser.add_argument(
        "--graph-adapter",
        action="store_true",
        help="Use stable query/metadata/output staging and per-layer captured graphs",
    )
    parser.add_argument("--extra-boundaries", action="store_true")
    parser.add_argument(
        "--graphs",
        action="store_true",
        help="Also capture prepared MBSA and served native unified plans",
    )
    args = parser.parse_args()
    trace = json.loads(args.trace.read_text())
    lengths = []
    for record in trace["records"]:
        case = tuple(tuple(pair) for pair in record.get("requests", []))
        if (
            record["phase"] == "serving"
            and record["method"] == "prefill_unified"
            and case not in lengths
        ):
            lengths.append(case)
    if args.extra_boundaries:
        lengths += [((1, 8193),), ((128, 8192),), ((8192, 32768),)]
    lengths = lengths[: args.limit]
    native, attention_cls, indexer_cls = native_modules()
    native.configure_unified_prefill_capacity(
        max_num_seqs=max(map(len, lengths)),
        max_model_len=max(kn for case in lengths for _, kn in case),
        block_size=128,
    )
    native.prepare_unified_prefill_storage(
        torch.device("cuda", 0),
        # Match the scheduler's TileQ=256 capacity buckets. An observed batch
        # may have 4095 live tokens under a 4096-token serving budget.
        max_num_batched_tokens=(
            (max(sum(qn for qn, _ in case) for case in lengths) + 255) // 256
        )
        * 256,
    )
    payload = {
        "config": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "policy": "warm_L2_alternating_eager_and_prepared_graph_CUDA_events_and_synchronized_wall",
        "results": [],
    }
    payload["environment"] = {
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(),
        "native_source_sha256": hashlib.sha256(
            Path(native.__file__).read_bytes()
        ).hexdigest(),
        "trace_sha256": hashlib.sha256(args.trace.read_bytes()).hexdigest(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for case in lengths:
        result = run_case(case, native, attention_cls, indexer_cls, args)
        payload["results"].append(result)
        args.output.write_text(json.dumps(payload, indent=2) + "\n")
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()

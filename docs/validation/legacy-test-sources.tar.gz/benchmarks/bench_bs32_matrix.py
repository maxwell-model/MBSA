#!/usr/bin/env python3
"""Execute the declared BS32 boundary matrix; persist every option result.

The HF oracle loads only unmodified attention methods from a pinned source
file, avoiding model initialization. Timings measure operators, not serving.
"""

from __future__ import annotations

import argparse
import ast
import gc
import hashlib
import itertools
import json
import statistics
import sys
import time
import traceback
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import torch
import torch.nn.functional as F

from mbsa import prepare_cutedsl_pipeline


def select_cases():
    config_dir = ROOT / "benchmarks/configs"
    manifest = json.loads((config_dir / "bs32_8k_256k.json").read_text())
    selected = []
    for kv in manifest["kv_domain"]["anchors"]:
        for q in (16, 17, 127, 128, 129, 255, 256):
            selected.append(
                {
                    "config_id": f"uniform-q{q}-kv{kv}",
                    "family": "pure_prefill_uniform",
                    "requests": [
                        {"phase": "prefill", "q": q, "kv": kv} for _ in range(32)
                    ],
                    "seed": 17,
                }
            )
    all_mixed = [
        json.loads(line)
        for line in (config_dir / "bs32_mixed_varlen.jsonl").read_text().splitlines()
    ]
    anchors = manifest["kv_domain"]["anchors"]
    for p in range(1, 33):
        kv = anchors[p - 1]
        for pattern in ("balanced_full", "skew_full"):
            selected.extend(
                c
                for c in all_mixed
                if c["config_id"] == f"p{p}-d{32 - p}-kv{kv}-{pattern}"
            )
        # One full and one underfilled ragged batch per P; cycle seeds/order.
        random_cases = [
            c
            for c in all_mixed
            if c["prefill_requests"] == p
            and "seed" in c
            and len({r["kv"] for r in c["requests"]}) > 1
        ]
        for full in (True, False):
            choices = [c for c in random_cases if (c["total_q"] == 8192) == full]
            if not choices:
                raise ValueError(f"missing random cases for P={p}, full={full}")
            selected.append(choices[(p - 1) % len(choices)])
    boundary_kv = {8192, 65536, 131072, 262144}
    selected.extend(
        c
        for c in all_mixed
        if c.get("pattern") == "single_prefill_boundary"
        and c["requests"][-1]["kv"] in boundary_kv
    )
    unique = {c["config_id"]: c for c in selected}
    # Decode requests only reserve scheduler tokens. The measured packed
    # operator receives prefill requests and their KV caches exclusively.
    for case in unique.values():
        case["scheduler_requests"] = case["requests"]
        case["scheduler_total_q"] = sum(r["q"] for r in case["requests"])
        case["reserved_decode_tokens"] = sum(
            r["q"] for r in case["requests"] if r["phase"] == "decode"
        )
        case["requests"] = [r for r in case["requests"] if r["phase"] == "prefill"]
        case["prefill_total_q"] = sum(r["q"] for r in case["requests"])
        case["measurement_scope"] = "prefill_only_v2"
    # Put a representative mixed case first for a cold-start probe.
    return sorted(
        unique.values(),
        key=lambda c: (
            0 if c["config_id"] == "p1-d31-kv8192-balanced_full" else 1,
            max(r["kv"] for r in c["requests"]),
            c["config_id"],
        ),
    )


def hf_class(source):
    tree = ast.parse(source.read_text())
    original = next(
        c
        for c in tree.body
        if isinstance(c, ast.ClassDef) and c.name == "CompassMoeBlockSparseGQAAttention"
    )
    names = {
        "_query_positions",
        "_allowed_keys",
        "_select_blocks",
        "_build_block_aligned_route",
        "_sparse_attention",
    }
    methods = [
        n for n in original.body if isinstance(n, ast.FunctionDef) and n.name in names
    ]
    assert len(methods) == len(names)
    module = ast.Module(
        body=[
            ast.ClassDef(
                name="PinnedHFAttention",
                bases=[],
                keywords=[],
                body=methods,
                decorator_list=[],
            )
        ],
        type_ignores=[],
    )
    namespace = {"torch": torch, "F": F}
    exec(compile(ast.fix_missing_locations(module), str(source), "exec"), namespace)
    cls = namespace["PinnedHFAttention"]
    instance = cls()
    instance.block_size = 128
    instance.num_remote_blocks = 16
    instance.num_prefix_blocks = instance.num_local_blocks = 8
    instance.prefix_window_size = instance.local_window_size = 1024
    instance.query_chunk_size = 16
    instance.softmax_scale = 128**-0.5
    instance.indexer = SimpleNamespace(index_softmax_scale=128**-0.5)
    return instance


def probe_positions(qn, kn):
    if qn <= 2:
        return list(range(qn))
    offset = kn - qn
    boundary = ((offset + 127) // 128) * 128 - offset
    return sorted(
        {
            x
            for x in (0, qn - 1, qn // 2, boundary - 1, boundary, boundary + 1)
            if 0 <= x < qn
        }
    )


def make_inputs(case, mapping):
    requests = case["requests"]
    q_lens, k_lens = ([r[name] for r in requests] for name in ("q", "kv"))
    counts = [(n + 127) // 128 for n in k_lens]
    generator = torch.Generator(device="cuda").manual_seed(case.get("seed", 17))
    rand = lambda shape: torch.randn(
        shape, device="cuda", dtype=torch.bfloat16, generator=generator
    )
    q = rand((sum(q_lens), 32, 128))
    iq = rand((sum(q_lens), 4, 128))
    pool = rand((sum(counts), 128, 4, 2, 128))
    ik = rand((sum(counts), 1, 128, 128))
    pages = torch.arange(sum(counts), device="cuda", dtype=torch.int32)
    if mapping == "permuted":
        pages = pages.flip(0)
    table = torch.zeros((len(requests), max(counts)), device="cuda", dtype=torch.int32)
    page_start = 0
    for row, count in enumerate(counts):
        table[row, :count].copy_(pages[page_start : page_start + count])
        page_start += count

    def prefix(values):
        return torch.tensor(
            [0] + list(itertools.accumulate(values)), device="cuda", dtype=torch.int32
        )

    return dict(
        q=q,
        iq=iq,
        pool=pool,
        ik=ik,
        pages=pages,
        table=table,
        cu_q=prefix(q_lens),
        cu_k=prefix(k_lens),
        counts=counts,
    )


def oracle_checks(case, data, hf, *, full=True):
    probes = []
    start = 0
    for i, request in enumerate(case["requests"]):
        qn, kn = request["q"], request["kv"]
        ids = data["table"][i, : data["counts"][i]].long()
        positions = list(range(qn)) if full else probe_positions(qn, kn)
        rows = torch.tensor([start + p for p in positions], device="cuda")
        q, iq = data["q"][rows], data["iq"][rows]
        selected_pool = data["pool"].index_select(0, ids)
        k = selected_pool[..., 0, :].reshape(-1, 4, 128)[:kn]
        v = selected_pool[..., 1, :].reshape(-1, 4, 128)[:kn]
        ik = data["ik"].index_select(0, ids).reshape(-1, 1, 128)[:kn]
        absolute = torch.tensor([kn - qn + p for p in positions], device="cuda")
        qp = hf._query_positions(
            batch_size=1,
            query_len=len(positions),
            key_len=kn,
            device=q.device,
            cache_position=absolute,
        )
        allowed = hf._allowed_keys(query_positions=qp, key_len=kn, attention_mask=None)
        remote = hf._select_blocks(
            iq.transpose(0, 1)[None], ik[:, 0][None], qp, allowed
        )
        complete = hf._build_block_aligned_route(remote, qp)
        expected = hf._sparse_attention(
            q.transpose(0, 1)[None],
            k.transpose(0, 1)[None],
            v.transpose(0, 1)[None],
            complete,
            allowed,
        )[0].transpose(0, 1)
        # LSE is an optional addition to the retained source, not an HF output.
        from mbsa.reference import MaxwellBlockSparseAttentionReference

        ref = MaxwellBlockSparseAttentionReference(index_head_dim=128, head_dim=128)
        retained_out, lse = ref._sparse_attention(
            q.transpose(0, 1)[None],
            k.transpose(0, 1)[None],
            v.transpose(0, 1)[None],
            complete,
            allowed,
            return_lse=True,
        )
        torch.testing.assert_close(
            retained_out[0].transpose(0, 1), expected, atol=0, rtol=0
        )
        probes.append(
            {
                "request": i,
                "rows": rows,
                "positions": positions,
                "out": expected.contiguous(),
                "lse": lse[0].transpose(0, 1).contiguous(),
                "route": remote[0].permute(1, 0, 2).contiguous(),
            }
        )
        start += qn
        del selected_pool, k, v, ik
    torch.cuda.synchronize()
    return probes


def route_metrics(actual, expected):
    # Compare sets of valid block IDs; -1 padding is excluded from overlap.
    match = (actual.sort(-1).values == expected.sort(-1).values).all(-1)
    intersection = (
        ((actual[..., :, None] == expected[..., None, :]) & (actual[..., :, None] >= 0))
        .any(-1)
        .sum(-1)
    )
    valid_expected = (expected >= 0).sum(-1)
    valid_actual = (actual >= 0).sum(-1)
    missing = valid_expected - intersection
    extra = valid_actual - intersection
    return {
        "query_head_count": match.numel(),
        "mismatched_query_heads": int((~match).sum()),
        "missing_blocks": int(missing.sum()),
        "extra_blocks": int(extra.sum()),
        "expected_valid_blocks": int(valid_expected.sum()),
        "intersection_blocks": int(intersection.sum()),
        "max_missing_blocks_per_query_head": int(missing.max()),
        "max_extra_blocks_per_query_head": int(extra.max()),
    }


def compare(actual, probes):
    out, lse, route = actual
    expected_out = torch.cat([p["out"] for p in probes])
    rows = torch.cat([p["rows"] for p in probes])
    actual_out = out[rows]
    diff = (actual_out.float() - expected_out.float()).abs()
    normalized = diff / (0.03 + 0.03 * expected_out.float().abs())
    expected_lse = torch.cat([p["lse"] for p in probes])
    ld = (lse[rows].float() - expected_lse.float()).abs()
    ln = ld / (0.01 + 0.002 * expected_lse.float().abs())
    expected_route = torch.cat([p["route"] for p in probes], dim=1)
    route_stat = route_metrics(route[:, rows], expected_route)
    return {
        "status": "passed"
        if float(normalized.max()) <= 1
        and float(ln.max()) <= 1
        and route_stat["mismatched_query_heads"] == 0
        else "failed",
        "checked_queries": rows.numel(),
        "total_queries": out.shape[0],
        "output_max_abs": float(diff.max()),
        "output_rms": float(diff.square().mean().sqrt()),
        "output_max_tolerance_ratio": float(normalized.max()),
        "output_query_head_max_abs_quantiles": torch.quantile(
            diff.amax(-1).flatten(), torch.tensor([0.5, 0.9, 0.99, 1.0], device="cuda")
        ).tolist(),
        "lse_max_abs": float(ld.max()),
        "lse_max_tolerance_ratio": float(ln.max()),
        "route": route_stat,
    }


def measure(functions, flush, args):
    for _ in range(args.warmups):
        for fn in functions.values():
            fn()
    torch.cuda.synchronize()
    result = {}
    for l2 in ("warm", "cold"):
        values = {
            name: {"gpu_samples_ms": [], "wall_samples_ms": []} for name in functions
        }
        for sample in range(args.samples):
            items = list(functions.items())
            if sample % 2:
                items.reverse()
            for name, fn in items:
                torch.cuda.synchronize()
                if l2 == "cold":
                    flush.add_(1)
                    torch.cuda.synchronize()
                begin, end = (torch.cuda.Event(enable_timing=True) for _ in range(2))
                started = time.perf_counter()
                begin.record()
                fn()
                end.record()
                end.synchronize()
                values[name]["wall_samples_ms"].append(
                    (time.perf_counter() - started) * 1000
                )
                values[name]["gpu_samples_ms"].append(begin.elapsed_time(end))
        for name, samples in values.items():
            samples["gpu_median_ms"] = statistics.median(samples["gpu_samples_ms"])
            samples["wall_median_ms"] = statistics.median(samples["wall_samples_ms"])
            samples["gpu_p95_ms"] = sorted(samples["gpu_samples_ms"])[
                int((args.samples - 1) * 0.95)
            ]
            result[name, l2] = samples
    return result


def append(path, value):
    with path.open("a") as f:
        f.write(json.dumps(value, ensure_ascii=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hf-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=19)
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--case-id", action="append")
    parser.add_argument(
        "--case-list",
        type=Path,
        help="JSON list of selected config IDs for a GPU shard",
    )
    parser.add_argument("--selection-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument(
        "--boundary-oracle",
        action="store_true",
        help="Pilot only; check boundary queries",
    )
    parser.add_argument(
        "--save-oracles", type=Path, help="Cache CPU oracle tensors for native replay"
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    cases = select_cases()
    if args.case_id:
        cases = [c for c in cases if c["config_id"] in args.case_id]
    if args.case_list:
        allowed_ids = set(json.loads(args.case_list.read_text()))
        cases = [c for c in cases if c["config_id"] in allowed_ids]
    if args.limit:
        cases = cases[: args.limit]
    options = list(
        itertools.product(
            ("bf16", "fp8"), ("identity", "permuted"), ("auto", "off", "on")
        )
    )
    (args.output / "selected-cases.json").write_text(json.dumps(cases, indent=2))
    if args.selection_only:
        print(json.dumps({"cases": len(cases), "option_results": len(cases) * 48}))
        return
    hf = hf_class(args.hf_source)
    if args.save_oracles:
        args.save_oracles.mkdir(parents=True, exist_ok=True)
    if torch.cuda.get_device_capability() not in ((9, 0), (10, 3)):
        raise RuntimeError("requires SM90 or SM103")
    environment = {
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(),
        "gpu_capability": torch.cuda.get_device_capability(),
        "initial_memory_free_total_bytes": torch.cuda.mem_get_info(),
        "hf_source_sha256": hashlib.sha256(args.hf_source.read_bytes()).hexdigest(),
        "hf_revision": "d97a6c52967a5ed332e2196a5b985f0b4a475549",
        "source_sha256": {
            str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT / "python/mbsa").rglob("*.py"))
        },
        "samples": args.samples,
        "warmups": args.warmups,
        "cold_l2_flush_mib": 256,
        "oracle_scope": "boundary queries"
        if args.boundary_oracle
        else "all queries of every selected shape",
        "measurement_scope": "prefill_only_v2",
        "selected_cases": len(cases),
        "planned_operator_results": len(cases) * 48,
    }
    (args.output / "environment.json").write_text(json.dumps(environment, indent=2))
    path = args.output / "results.jsonl"
    finished = set()
    if args.resume and path.exists():
        for line in path.read_text().splitlines():
            r = json.loads(line)
            finished.add(
                (
                    r["config_id"],
                    r["partial_dtype"],
                    r["page_mapping"],
                    r["overlap"],
                    r["execution"],
                    r["l2"],
                )
            )
    elif path.exists():
        raise FileExistsError("use --resume or a new output directory")
    flush = torch.empty(256 * 1024 * 1024, dtype=torch.uint8, device="cuda")
    for number, case in enumerate(cases, 1):
        if all(
            (case["config_id"], dtype, mapping, overlap, execution, l2) in finished
            for dtype, mapping, overlap in options
            for execution, l2 in itertools.product(
                ("eager", "prepared_graph"), ("warm", "cold")
            )
        ):
            print(
                json.dumps(
                    {
                        "case": number,
                        "of": len(cases),
                        "id": case["config_id"],
                        "resume_skipped": True,
                    }
                ),
                flush=True,
            )
            continue
        case_started = time.perf_counter()
        for mapping in ("identity", "permuted"):
            data = probes = None
            allocation_error = None
            try:
                data = make_inputs(case, mapping)
                probes = oracle_checks(case, data, hf, full=not args.boundary_oracle)
                if args.save_oracles:
                    torch.save(
                        [
                            {
                                k: v.cpu() if isinstance(v, torch.Tensor) else v
                                for k, v in p.items()
                            }
                            for p in probes
                        ],
                        args.save_oracles / f"{case['config_id']}-{mapping}.pt",
                    )
            except Exception as exc:
                allocation_error = {
                    "status": "oom"
                    if isinstance(exc, torch.OutOfMemoryError)
                    else "error",
                    "exception": str(exc),
                    "traceback": traceback.format_exc(),
                }
            for dtype, page_mapping, overlap in options:
                if page_mapping != mapping:
                    continue
                base = {
                    "config_id": case["config_id"],
                    "family": case["family"],
                    "partial_dtype": dtype,
                    "page_mapping": mapping,
                    "overlap": overlap,
                    "q_lens": [r["q"] for r in case["requests"]],
                    "kv_lens": [r["kv"] for r in case["requests"]],
                    "seed": case.get("seed", 17),
                }
                keys = [
                    (case["config_id"], dtype, mapping, overlap, ex, l2)
                    for ex in ("eager", "prepared_graph")
                    for l2 in ("warm", "cold")
                ]
                if all(key in finished for key in keys):
                    continue
                pipeline = None
                try:
                    if allocation_error is not None:
                        raise RuntimeError(allocation_error["exception"])
                    torch.cuda.reset_peak_memory_stats()
                    started = time.perf_counter()
                    pipeline = prepare_cutedsl_pipeline(
                        data["iq"],
                        data["ik"],
                        data["q"],
                        data["pool"][..., 0, :].permute(0, 2, 1, 3),
                        data["pool"][..., 1, :].permute(0, 2, 1, 3),
                        cu_seqlens_q=data["cu_q"],
                        cu_seqlens_k=data["cu_k"],
                        index_page_indices=data["pages"],
                        page_table=data["table"],
                        partial_dtype=torch.bfloat16
                        if dtype == "bf16"
                        else torch.float8_e4m3fn,
                        overlap_fixed_score={"auto": None, "off": False, "on": True}[
                            overlap
                        ],
                    )
                    first = pipeline.run()
                    torch.cuda.synchronize()
                    prepare_ms = (time.perf_counter() - started) * 1000
                    precision = compare(first, probes)
                    started = time.perf_counter()
                    pipeline.plan.capture_mega_graph()
                    pipeline.plan.run_mega()
                    torch.cuda.synchronize()
                    capture_ms = (time.perf_counter() - started) * 1000
                    graph_precision = compare(
                        (
                            pipeline.plan.attention.out,
                            pipeline.plan.attention.out_lse,
                            pipeline.plan.attention.tile_plan.dynamic_route,
                        ),
                        probes,
                    )
                    # Explicitly compare a replay after changing live query values.
                    original_q = data["q"].clone()
                    data["q"].add_(0.125)
                    pipeline.plan.run_mega()
                    graph_out = pipeline.plan.attention.out.clone()
                    eager_out = pipeline.run()[0]
                    torch.testing.assert_close(graph_out, eager_out, atol=0, rtol=0)
                    data["q"].copy_(original_q)
                    del original_q, graph_out, eager_out
                    times = measure(
                        {
                            "eager": pipeline.run,
                            "prepared_graph": pipeline.plan.run_mega,
                        },
                        flush,
                        args,
                    )
                    memory = {
                        "allocated_peak_bytes": torch.cuda.max_memory_allocated(),
                        "reserved_peak_bytes": torch.cuda.max_memory_reserved(),
                        "free_total_bytes": torch.cuda.mem_get_info(),
                    }
                    for (execution, l2), timing in times.items():
                        check = precision if execution == "eager" else graph_precision
                        append(
                            path,
                            {
                                **base,
                                "execution": execution,
                                "l2": l2,
                                "status": check["status"],
                                "precision": check,
                                "timing": timing,
                                "memory": memory,
                                "prepare_first_run_ms": prepare_ms,
                                "capture_ms": capture_ms,
                                "live_query_graph_replay": "passed",
                            },
                        )
                except Exception as exc:
                    failure = allocation_error or {
                        "status": "oom"
                        if isinstance(exc, torch.OutOfMemoryError)
                        else "error",
                        "exception": str(exc),
                        "traceback": traceback.format_exc(),
                    }
                    for execution, l2 in itertools.product(
                        ("eager", "prepared_graph"), ("warm", "cold")
                    ):
                        append(
                            path, {**base, "execution": execution, "l2": l2, **failure}
                        )
                finally:
                    del pipeline
                    gc.collect()
                    torch.cuda.empty_cache()
            del data, probes
            gc.collect()
            torch.cuda.empty_cache()
        print(
            json.dumps(
                {
                    "case": number,
                    "of": len(cases),
                    "id": case["config_id"],
                    "elapsed_s": time.perf_counter() - case_started,
                }
            ),
            flush=True,
        )
    (args.output / "complete.json").write_text(
        json.dumps({"cases": len(cases), "status": "complete"})
    )


if __name__ == "__main__":
    main()

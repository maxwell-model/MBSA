#!/usr/bin/env python3
"""CuTe DSL correctness and cold-L2 end-to-end/stage timings."""

from __future__ import annotations
import argparse
import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
import torch
from mbsa import prepare_cutedsl_pipeline, reference_pipeline


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--q-lens", type=int, nargs="+", default=[8192])
    parser.add_argument("--kv-lens", type=int, nargs="+", default=[32768])
    parser.add_argument("--shuffle-index-pages", action="store_true")
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--samples", type=int, default=11)
    parser.add_argument("--l2-flush-mib", type=int, default=256)
    parser.add_argument("--seed", type=int, default=17)
    parser.add_argument("--check-queries", type=int, default=16)
    args = parser.parse_args()
    q_lens, kv_lens = args.q_lens, args.kv_lens
    if len(q_lens) != len(kv_lens) or any(
        not 0 < qn <= min(kn, 8192) or kn > 1048576 for qn, kn in zip(q_lens, kv_lens)
    ):
        parser.error("each request requires 0 < Q <= 8192 and Q <= KV <= 1M")
    if (
        args.samples < 1
        or args.warmups < 0
        or args.check_queries < 1
        or args.l2_flush_mib < 0
    ):
        parser.error("invalid measurement or correctness parameters")
    if not torch.cuda.is_available() or torch.cuda.get_device_capability() not in (
        (9, 0),
        (10, 3),
    ):
        parser.error("the qualified CuTe DSL runtime requires SM90 or SM103")
    torch.manual_seed(args.seed)

    def rand(shape):
        return torch.randn(shape, device="cuda", dtype=torch.bfloat16)

    def prefix(lengths):
        values = [0]
        for n in lengths:
            values.append(values[-1] + n)
        return torch.tensor(values, device="cuda", dtype=torch.int32)

    iq = rand((sum(q_lens), 4, 128))
    q = rand((sum(q_lens), 32, 128))
    blocks = [(n + 127) // 128 for n in kv_lens]
    logical_ik = rand((sum(blocks), 1, 128, 128))
    pages = (
        torch.randperm(sum(blocks), device="cuda")
        if args.shuffle_index_pages
        else torch.arange(sum(blocks), device="cuda")
    )
    ik = torch.empty_like(logical_ik)
    ik.index_copy_(0, pages, logical_ik)
    k = rand((sum(kv_lens), 4, 128))
    v = rand(k.shape)
    packed = len(q_lens) > 1
    runtime = prepare_cutedsl_pipeline(
        iq,
        ik,
        q,
        k,
        v,
        index_page_indices=pages.to(torch.int32),
        cu_seqlens_q=prefix(q_lens) if packed else None,
        cu_seqlens_k=prefix(kv_lens) if packed else None,
    )
    actual = runtime.run()
    torch.cuda.synchronize()
    q_start = k_start = page_start = 0
    errors = []
    for qn, kn, nb in zip(q_lens, kv_lens, blocks):
        check = min(args.check_queries, qn)
        # Check both early and final queries without building a Q x KV oracle
        # for the whole benchmark batch. Each subset keeps its absolute position.
        for begin in sorted({0, qn - check}):
            qs = slice(q_start + begin, q_start + begin + check)
            local_ik = logical_ik[page_start : page_start + nb].view(-1, 1, 128)[:kn]
            expected = reference_pipeline(
                iq[qs],
                local_ik,
                q[qs],
                k[k_start : k_start + kn],
                v[k_start : k_start + kn],
                query_offset=kn - qn + begin,
            )
            eo, el, er = expected
            torch.testing.assert_close(
                actual[2][:, qs].sort(-1).values, er.sort(-1).values, rtol=0, atol=0
            )
            torch.testing.assert_close(actual[0][qs], eo, rtol=0.03, atol=0.03)
            torch.testing.assert_close(actual[1][qs], el, rtol=0.002, atol=0.01)
            errors.append(
                {
                    "q_start": q_start + begin,
                    "queries": check,
                    "output_max_abs": float(
                        (actual[0][qs].float() - eo.float()).abs().max()
                    ),
                    "lse_max_abs": float((actual[1][qs] - el).abs().max()),
                }
            )
        q_start += qn
        k_start += kn
        page_start += nb
    flush = torch.empty(
        args.l2_flush_mib * 1024 * 1024, device="cuda", dtype=torch.uint8
    )

    def measure(fn):
        for _ in range(args.warmups):
            fn()
        torch.cuda.synchronize()
        samples = []
        for _ in range(args.samples):
            flush.add_(1)
            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)
            start.record()
            fn()
            end.record()
            end.synchronize()
            samples.append(start.elapsed_time(end))
        return {"median_ms": statistics.median(samples), "samples_ms": samples}

    plan = runtime.plan
    stages = {
        "router": plan.run_score,
        "csr_lpt": plan.run_plan,
        "fixed": plan.attention.run_fixed,
        "dynamic_and_combine": plan.attention.run_dynamic,
        "merge": plan.attention.run_merge,
    }
    timings = {"e2e": measure(runtime.run)}
    timings.update({name: measure(fn) for name, fn in stages.items()})
    print(
        json.dumps(
            {
                "q_lens": q_lens,
                "kv_lens": kv_lens,
                "index_layout": "permuted" if args.shuffle_index_pages else "identity",
                "l2_flush_mib": args.l2_flush_mib,
                "precision_checks": errors,
                "timings": timings,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()

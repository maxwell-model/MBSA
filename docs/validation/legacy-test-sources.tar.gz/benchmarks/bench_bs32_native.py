#!/usr/bin/env python3
"""Native vLLM replay with quantitative routing/output comparison to pinned HF."""

import argparse
import gc
import hashlib
import importlib
import importlib.util
import itertools
import json
import os
import time
import traceback
from pathlib import Path

import torch

from bench_bs32_matrix import (
    append,
    hf_class,
    make_inputs,
    measure,
    oracle_checks,
    route_metrics,
    select_cases,
)


def native_modules():
    for stem, prefix in (
        ("maxwell_moe", "MaxwellMoe"),
        ("maxwell_v1", "MaxwellV1"),
        ("compass", "Compass"),
    ):
        name = f"vllm.model_executor.layers.{stem}_bsa"
        if importlib.util.find_spec(name) is not None:
            attention = importlib.import_module(name)
            indexer = importlib.import_module(name + "_indexer")
            return (
                attention,
                getattr(attention, prefix + "BsaSparseGqa"),
                getattr(indexer, prefix + "BsaIndexer"),
            )
    raise RuntimeError("native sparse Attention not found")


def compare(out, route, probes):
    rows = torch.cat([p["rows"] for p in probes])
    expected = torch.cat([p["out"] for p in probes])
    diff = (out[rows].float() - expected.float()).abs()
    normalized = diff / (0.03 + 0.03 * expected.float().abs())
    routes = route_metrics(route[:, rows], torch.cat([p["route"] for p in probes], 1))
    return {
        "checked_queries": rows.numel(),
        "output_max_abs": float(diff.max()),
        "output_rms": float(diff.square().mean().sqrt()),
        "output_max_tolerance_ratio": float(normalized.max()),
        "output_close_fraction": float((normalized <= 1).float().mean()),
        "output_passed": bool((normalized <= 1).all()),
        "route": routes,
        "status": "passed"
        if bool((normalized <= 1).all()) and routes["mismatched_query_heads"] == 0
        else "failed",
    }


def remote_from_complete(route, lengths):
    positions = torch.cat(
        [torch.arange(kn - qn, kn, device="cuda") for qn, kn in lengths]
    )
    local_start = (positions // 128 - 7).clamp(min=8)
    valid = (route >= 8) & (route < local_start[None, :, None])
    sorted_remote = torch.where(valid, route, 2**30).sort(-1).values[..., :16]
    return torch.where(sorted_remote == 2**30, -1, sorted_remote)


def score_gap(case, data, probes, route):
    """FP32 max-dot score gap for mismatched sampled routes only."""
    losses, missing_scores, extra_scores = [], [], []
    for p in probes:
        i = p["request"]
        kn = case["requests"][i]["kv"]
        ids = data["table"][i, : data["counts"][i]].long()
        ik = data["ik"].index_select(0, ids).reshape(-1, 128)[:kn]
        # Routing counts are over all Q; score-gap diagnostics use at most
        # eight mismatched queries per request to bound the FP32 temporary.
        actual_all = route[:, p["rows"]]
        mismatch_queries = (
            (actual_all.sort(-1).values != p["route"].sort(-1).values)
            .any(-1)
            .any(0)
            .nonzero()
            .flatten()
        )
        if not mismatch_queries.numel():
            continue
        chosen = mismatch_queries[
            torch.linspace(
                0,
                mismatch_queries.numel() - 1,
                min(8, mismatch_queries.numel()),
                device="cuda",
            ).long()
        ]
        iq = data["iq"][p["rows"][chosen]]
        # Only store block scores, bounded to a handful of probe queries.
        scores = torch.einsum("qgd,kd->gqk", iq.float(), ik.float()) * 128**-0.5
        scores = torch.nn.functional.pad(scores, (0, (-kn) % 128), value=-torch.inf)
        blocks = scores.reshape(4, iq.shape[0], -1, 128).amax(-1)
        actual = actual_all[:, chosen].cpu()
        expected = p["route"][:, chosen].cpu()
        block_cpu = blocks.cpu()
        for g, q in (
            (actual.sort(-1).values != expected.sort(-1).values)
            .any(-1)
            .nonzero()
            .tolist()
        ):
            a = set(actual[g, q].tolist()) - {-1}
            e = set(expected[g, q].tolist()) - {-1}
            missed, added = e - a, a - e
            ms = [
                float(block_cpu[g, q, b]) for b in missed if 0 <= b < blocks.shape[-1]
            ]
            es = [float(block_cpu[g, q, b]) for b in added if 0 <= b < blocks.shape[-1]]
            missing_scores.extend(ms)
            extra_scores.extend(es)
            losses.append(sum(ms) - sum(es))
    return {
        "mismatched_query_heads_scored": len(losses),
        "sum_selected_score_loss": sum(losses),
        "max_selected_score_loss": max(losses, default=0),
        "mean_selected_score_loss": sum(losses) / max(len(losses), 1),
        "missing_block_score_mean": sum(missing_scores) / max(len(missing_scores), 1),
        "extra_block_score_mean": sum(extra_scores) / max(len(extra_scores), 1),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--hf-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--partial-dtype", choices=("bf16", "fp8"), required=True)
    parser.add_argument("--samples", type=int, default=19)
    parser.add_argument("--warmups", type=int, default=5)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--case-id", action="append")
    parser.add_argument("--case-list", type=Path)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--oracle-cache", type=Path)
    args = parser.parse_args()
    os.environ["MAXWELL_BSA_PREFILL_FP8_PARTIALS"] = (
        "0" if args.partial_dtype == "bf16" else "1"
    )
    os.environ["MBSA_VLLM_PREFILL"] = "0"
    args.output.mkdir(parents=True, exist_ok=True)
    cases = select_cases()
    if args.case_id:
        cases = [c for c in cases if c["config_id"] in args.case_id]
    if args.case_list:
        allowed_ids = set(json.loads(args.case_list.read_text()))
        cases = [c for c in cases if c["config_id"] in allowed_ids]
    if args.limit:
        cases = cases[: args.limit]
    hf = hf_class(args.hf_source)
    native, attention_cls, indexer_cls = native_modules()
    (args.output / f"environment-{args.partial_dtype}.json").write_text(
        json.dumps(
            {
                "module": native.__name__,
                "path": native.__file__,
                "source_sha256": hashlib.sha256(
                    Path(native.__file__).read_bytes()
                ).hexdigest(),
                "gpu": torch.cuda.get_device_name(),
                "torch": torch.__version__,
                "hf_sha256": hashlib.sha256(args.hf_source.read_bytes()).hexdigest(),
                "dtype": args.partial_dtype,
                "cases": len(cases),
            },
            indent=2,
        )
    )
    native.configure_unified_prefill_capacity(
        max_num_seqs=32, max_model_len=262144, block_size=128
    )
    native.prepare_unified_prefill_storage(
        torch.device("cuda", 0), max_num_batched_tokens=8192
    )
    flush = torch.empty(256 * 1024 * 1024, device="cuda", dtype=torch.uint8)
    path = args.output / f"native-{args.partial_dtype}.jsonl"
    finished = set()
    if args.resume and path.exists():
        for line in path.read_text().splitlines():
            r = json.loads(line)
            finished.add((r["config_id"], r["page_mapping"], r["execution"], r["l2"]))
    elif path.exists():
        raise FileExistsError("use --resume or a new output directory")
    for number, case in enumerate(cases, 1):
        started = time.perf_counter()
        for mapping in ("identity", "permuted"):
            if all(
                (case["config_id"], mapping, execution, l2) in finished
                for execution, l2 in itertools.product(
                    ("eager", "prepared_graph"), ("warm", "cold")
                )
            ):
                continue
            base = {
                "config_id": case["config_id"],
                "family": case["family"],
                "page_mapping": mapping,
                "partial_dtype": args.partial_dtype,
            }
            data = probes = indexer = attention = plan = graph = common = functions = (
                out
            ) = route = None
            try:
                data = make_inputs(case, mapping)
                # Native varlen plans bucket logical KV extent in 128-page
                # groups. Match that metadata contract, retaining valid pages.
                table_width = ((data["table"].shape[1] + 127) // 128) * 128
                if data["table"].shape[1] != table_width:
                    data["table"] = torch.nn.functional.pad(
                        data["table"], (0, table_width - data["table"].shape[1])
                    )
                cache = (
                    args.oracle_cache / f"{case['config_id']}-{mapping}.pt"
                    if args.oracle_cache
                    else None
                )
                if cache and cache.exists():
                    probes = torch.load(cache, map_location="cuda", weights_only=True)
                else:
                    probes = oracle_checks(case, data, hf)
                lengths = [(r["q"], r["kv"]) for r in case["requests"]]
                indexer = indexer_cls(
                    num_index_heads=4,
                    num_kv_heads=4,
                    head_dim=128,
                    block_size=128,
                    shared_route=False,
                    score_reduce="max",
                    init_blocks=8,
                    local_blocks=8,
                )
                indexer._k_cache = data["ik"]
                attention = attention_cls(
                    num_qo_heads=32,
                    num_kv_heads=4,
                    head_dim=128,
                    block_size=128,
                    topk=32,
                    shared_route=False,
                )
                plan = indexer.build_plan(
                    qo_lens=torch.tensor([qn for qn, _ in lengths], dtype=torch.int32),
                    kv_lens=torch.tensor([kn for _, kn in lengths], dtype=torch.int32),
                    qo_offset=torch.tensor(
                        [kn - qn for qn, kn in lengths], dtype=torch.int32
                    ),
                )
                out = torch.empty_like(data["q"])
                common = dict(
                    index_q=data["iq"],
                    index_k_cache=indexer.decode_k_cache(),
                    index_plan=plan,
                    index_page_indices=data["pages"],
                    page_table=data["table"],
                    seq_lens=torch.tensor(
                        [kn for _, kn in lengths], dtype=torch.int32, device="cuda"
                    ),
                    request_lens=lengths,
                    cu_seqlens_q=data["cu_q"],
                    cu_seqlens_k=data["cu_k"],
                    prefix_lens=torch.tensor(
                        [kn - qn for qn, kn in lengths],
                        dtype=torch.int32,
                        device="cuda",
                    ),
                    out=out,
                )

                def unified():
                    return attention.prefill_unified(
                        data["q"],
                        data["pool"][..., 0, :],
                        data["pool"][..., 1, :],
                        **common,
                    )

                first = unified()
                if first is None:
                    base["backend"] = "legacy_sparse_gqa_fallback"
                    base["unified_status"] = "unsupported_index_plan_no_tileq256_owner"
                    visible = torch.cat(
                        [
                            torch.arange(kn - qn, kn, device="cuda", dtype=torch.int32)
                            // 128
                            + 1
                            for qn, kn in lengths
                        ]
                    )

                    def legacy():
                        score = indexer.max_scores(
                            data["iq"], plan=plan, kv_indices=data["pages"]
                        )
                        selection = indexer.select(
                            score,
                            num_valid_pages=max(data["counts"]),
                            topk=32,
                            per_query_valid=visible,
                        )
                        attention.prefill(
                            data["q"],
                            data["pool"][..., 0, :],
                            data["pool"][..., 1, :],
                            selection,
                            cu_seqlens_q=data["cu_q"],
                            cu_seqlens_k=data["cu_k"],
                            seq_lens=common["seq_lens"],
                            page_table=data["table"],
                            max_seqlen_q=max(qn for qn, kn in lengths),
                            max_seqlen_k=max(kn for qn, kn in lengths),
                            total_rows=sum(data["counts"]),
                            total_k=sum(kn for qn, kn in lengths),
                            softmax_scale=128**-0.5,
                            out=out,
                        )
                        return selection

                    selection = legacy()
                    route = remote_from_complete(selection, lengths)
                    fn = legacy
                else:
                    base["backend"] = "native_unified"
                    base["unified_status"] = "supported"
                    route = native.unified_prefill_dynamic_route(
                        native._UNIFIED_PREFILL_STORAGE[0],
                        sum(qn for qn, kn in lengths),
                    ).clone()
                    fn = unified
                precision = compare(out, route, probes)
                gaps = score_gap(case, data, probes, route)
                functions = {"eager": fn}
                graph_error = None
                try:
                    stream = torch.cuda.Stream()
                    stream.wait_stream(torch.cuda.current_stream())
                    with torch.cuda.stream(stream):
                        for _ in range(3):
                            fn()
                    stream.synchronize()
                    graph = torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph, stream=stream):
                        captured_return = fn()
                    graph.replay()
                    torch.cuda.synchronize()
                    if base["backend"] == "native_unified":
                        graph_route = native.unified_prefill_dynamic_route(
                            native._UNIFIED_PREFILL_STORAGE[0],
                            sum(qn for qn, kn in lengths),
                        )
                    else:
                        graph_route = remote_from_complete(captured_return, lengths)
                    graph_precision = compare(out, graph_route, probes)
                    functions["prepared_graph"] = graph.replay
                except Exception as exc:
                    graph_error = str(exc)
                timings = measure(functions, flush, args)
                for (execution, l2), timing in timings.items():
                    check = precision if execution == "eager" else graph_precision
                    append(
                        path,
                        {
                            **base,
                            "execution": execution,
                            "l2": l2,
                            "status": check["status"],
                            "precision": check,
                            "score_gap": gaps,
                            "timing": timing,
                        },
                    )
                if graph_error:
                    for l2 in ("warm", "cold"):
                        append(
                            path,
                            {
                                **base,
                                "execution": "prepared_graph",
                                "l2": l2,
                                "status": "unsupported_graph",
                                "exception": graph_error,
                            },
                        )
            except Exception as exc:
                for execution, l2 in itertools.product(
                    ("eager", "prepared_graph"), ("warm", "cold")
                ):
                    append(
                        path,
                        {
                            **base,
                            "execution": execution,
                            "l2": l2,
                            "status": "oom"
                            if isinstance(exc, torch.OutOfMemoryError)
                            else "error",
                            "exception": str(exc),
                            "traceback": traceback.format_exc(),
                        },
                    )
            finally:
                native._UNIFIED_PREFILL_STATE.clear()
                data = probes = indexer = attention = plan = graph = common = (
                    functions
                ) = out = route = None
                gc.collect()
                torch.cuda.empty_cache()
        print(
            json.dumps(
                {
                    "case": number,
                    "of": len(cases),
                    "id": case["config_id"],
                    "elapsed_s": time.perf_counter() - started,
                }
            ),
            flush=True,
        )
    (args.output / f"complete-{args.partial_dtype}.json").write_text(
        json.dumps({"cases": len(cases), "status": "complete"})
    )


if __name__ == "__main__":
    main()

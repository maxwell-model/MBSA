#!/usr/bin/env python3
"""Qualify retained vLLM decode and MTP verification against the Python oracle.

Uses real interleaved cache strides, permuted physical pages, request-major
queries and per-token causal positions. Run identically in both containers.
"""

import argparse
import hashlib
import inspect
import json
from pathlib import Path

import torch

from bench_vllm_replay import measure, native_modules
from mbsa.reference import reference_pipeline


def oracle(q, iq, ik, k, v, table, lengths, query_len):
    outputs, routes = [], []
    for slot, kn in enumerate(lengths):
        count = (kn + 127) // 128
        ids = table[slot, :count].long()
        qs = slice(slot * query_len, (slot + 1) * query_len)
        expected, _, remote = reference_pipeline(
            iq[qs],
            ik[ids].reshape(-1, 1, 128)[:kn],
            q[qs],
            k[ids].reshape(-1, 4, 128)[:kn],
            v[ids].reshape(-1, 4, 128)[:kn],
        )
        current = torch.arange(kn - query_len, kn, device=q.device).div(
            128, rounding_mode="floor"
        )
        prefix = torch.arange(8, device=q.device).expand(4, query_len, 8)
        prefix = torch.where(prefix <= current[None, :, None], prefix, -1)
        local = current[None, :, None] + torch.arange(-7, 1, device=q.device)
        local = torch.where(local >= 8, local, -1).expand(4, query_len, 8)
        routes.append(torch.cat((prefix, remote, local), dim=-1).sort(-1).values)
        outputs.append(expected)
    return torch.cat(outputs), torch.cat(routes, dim=1).to(torch.int32)


def run_case(lengths, query_len, attention_cls, indexer_cls, args):
    torch.manual_seed(17)
    counts = [(kn + 127) // 128 for kn in lengths]
    pages, batch = sum(counts), len(lengths)

    def rand(shape):
        return torch.randn(shape, device="cuda", dtype=torch.bfloat16)

    q, iq = rand((batch * query_len, 32, 128)), rand((batch * query_len, 4, 128))
    pool = rand((pages, 128, 4, 2, 128))
    k, v = pool[..., 0, :], pool[..., 1, :]
    ik = rand((pages, 1, 128, 128))
    mapping = torch.arange(pages - 1, -1, -1, device="cuda", dtype=torch.int32)
    table = torch.zeros((batch, max(counts)), device="cuda", dtype=torch.int32)
    start = 0
    for slot, count in enumerate(counts):
        table[slot, :count].copy_(mapping[start : start + count])
        start += count
    seq = torch.tensor(lengths, device="cuda", dtype=torch.int32)
    indexer = indexer_cls(
        num_index_heads=4,
        num_kv_heads=4,
        head_dim=128,
        block_size=128,
        shared_route=False,
        score_reduce="max",
        init_blocks=8,
        local_blocks=8,
    )
    indexer._k_cache = ik
    attention = attention_cls(
        num_qo_heads=32,
        num_kv_heads=4,
        head_dim=128,
        block_size=128,
        topk=32,
        shared_route=False,
    )
    out = torch.empty_like(q)
    index_parameters = inspect.signature(indexer.decode_select).parameters
    attention_parameters = inspect.signature(attention.decode_triton).parameters
    batched_mtp = "decode_query_len" in index_parameters and (
        "decode_query_len" in attention_parameters
    )

    def one_step(query, index_query, seq_lens, destination, width):
        index_options = {"decode_query_len": width} if batched_mtp else {}
        attention_options = {"decode_query_len": width} if batched_mtp else {}
        if "out" in attention_parameters:
            attention_options["out"] = destination
        selection = indexer.decode_select(
            index_query,
            block_table=table,
            seq_lens=seq_lens,
            max_seq_len=max(lengths),
            topk=32,
            **index_options,
        )
        result = attention.decode_triton(
            query,
            k,
            v,
            selection,
            table,
            seq_lens,
            softmax_scale=128**-0.5,
            **attention_options,
        )
        return selection, result

    def run():
        nonlocal out
        if query_len > 1 and not batched_mtp:
            selections, outputs = [], []
            for offset in range(query_len):
                selection, output = one_step(
                    q[offset::query_len].contiguous(),
                    iq[offset::query_len].contiguous(),
                    seq - (query_len - offset - 1),
                    None,
                    1,
                )
                selections.append(selection)
                outputs.append(output)
            out = torch.stack(outputs, dim=1).flatten(0, 1)
            return torch.stack(selections, dim=2).flatten(1, 2)
        selection, out = one_step(q, iq, seq, out, query_len)
        return selection

    selection = run()
    expected, expected_route = oracle(q, iq, ik, k, v, table, lengths, query_len)
    torch.testing.assert_close(
        selection.sort(-1).values, expected_route, atol=0, rtol=0
    )
    torch.testing.assert_close(out, expected, atol=0.03, rtol=0.03)
    result = {
        "requests": [[query_len, kn] for kn in lengths],
        "key_stride": list(k.stride()),
        "output_max_abs_error": (out.float() - expected.float()).abs().max().item(),
        "route_exact": True,
        "decode_mode": "batched"
        if batched_mtp
        else (
            "legacy_single_query" if query_len == 1 else "legacy_serial_mtp_emulation"
        ),
        "caller_output_buffer": "out" in attention_parameters,
    }
    for _ in range(args.warmups):
        run()
    result["native_decode_eager"] = measure(run, args.samples)
    stream = torch.cuda.Stream()
    stream.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(stream):
        run()
    stream.synchronize()
    graph = torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph, stream=stream):
        captured_selection = run()
    # Verify a replay reads live queries/cache/table rather than cold values.
    q.add_(0.125)
    iq.mul_(0.75)
    pool.add_(0.0625)
    for slot, count in enumerate(counts):
        table[slot, :count].copy_(table[slot, :count].flip(0))
    graph.replay()
    expected, expected_route = oracle(q, iq, ik, k, v, table, lengths, query_len)
    torch.testing.assert_close(
        captured_selection.sort(-1).values, expected_route, atol=0, rtol=0
    )
    torch.testing.assert_close(out, expected, atol=0.03, rtol=0.03)
    result["graph_live_inputs_passed"] = True
    result["graph_output_max_abs_error"] = (
        (out.float() - expected.float()).abs().max().item()
    )
    result["native_decode_graph"] = measure(graph.replay, args.samples)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=9)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--extra-boundaries", action="store_true")
    args = parser.parse_args()
    trace = json.loads(args.trace.read_text())
    cases = []
    for record in trace["records"]:
        if record["phase"] != "serving" or record["method"] != "decode_triton":
            continue
        requests = record.get("requests", [])
        if not requests:
            continue
        query_len = requests[0][0]
        case = tuple(kn for _, kn in requests), query_len
        if case not in cases:
            cases.append(case)
    if args.extra_boundaries:
        for query_len in (1, 2, 4, 8):
            cases.extend(
                [
                    ((8193,), query_len),
                    ((128, 4096, 4097, 8192, 8193, 16384, 32768, 32769), query_len),
                ]
            )
    native, attention_cls, indexer_cls = native_modules()
    payload = {
        "kind": "retained_native_decode_vs_python_oracle",
        "policy": "warm_L2_CUDA_events_and_synchronized_wall",
        "environment": {
            "torch": torch.__version__,
            "gpu": torch.cuda.get_device_name(),
            "native_module": native.__name__,
            "native_source_sha256": hashlib.sha256(
                Path(native.__file__).read_bytes()
            ).hexdigest(),
            "trace_sha256": hashlib.sha256(args.trace.read_bytes()).hexdigest(),
        },
        "results": [],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for lengths, query_len in cases:
        result = run_case(lengths, query_len, attention_cls, indexer_cls, args)
        payload["results"].append(result)
        args.output.write_text(json.dumps(payload, indent=2) + "\n")
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()

import json
import sys
from pathlib import Path
from importlib.metadata import distribution

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
import mbsa
assert Path(mbsa.__file__).resolve().is_relative_to(root)
assert distribution('mbsa').metadata['Name'] == 'mbsa'
assert not {'torch', 'triton', 'cutlass'}.intersection(sys.modules)

import torch
from mbsa import reference_pipeline, triton_pipeline, prepare_cutedsl_pipeline

torch.manual_seed(17)
def rand(shape):
    return torch.randn(shape, device='cuda', dtype=torch.bfloat16)
operands = (rand((128, 4, 128)), rand((4096, 1, 128)), rand((128, 32, 128)), rand((4096, 4, 128)), rand((4096, 4, 128)))
expected = reference_pipeline(*operands)
results = []
for name, actual in (
    ('triton', triton_pipeline(*operands)),
    ('cutedsl', prepare_cutedsl_pipeline(*operands).run()),
):
    torch.testing.assert_close(actual[0], expected[0], rtol=0.03, atol=0.03)
    torch.testing.assert_close(actual[1], expected[1], rtol=0.002, atol=0.01)
    torch.testing.assert_close(actual[2].sort(-1).values, expected[2].sort(-1).values, rtol=0, atol=0)
    results.append({'backend': name, 'route_exact': True, 'output_max_abs': (actual[0].float() - expected[0].float()).abs().max().item(), 'lse_max_abs': (actual[1] - expected[1]).abs().max().item()})
print(json.dumps({'package': str(mbsa.__file__), 'q': 128, 'kv': 4096, 'results': results}))

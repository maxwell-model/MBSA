#!/usr/bin/env python3
"""Complete native shape coverage by restarting after a poisoned CUDA context.

Error records remain errors. A restart continues only unrecorded combinations;
it does not convert a CUDA fault into a passing precision result.
"""

import argparse
import itertools
import json
import subprocess
import sys
from pathlib import Path


def recorded(path):
    if not path.exists():
        return set()
    return {
        (r["config_id"], r["page_mapping"], r["execution"], r["l2"])
        for r in (json.loads(line) for line in path.read_text().splitlines())
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--hf-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--partial-dtype", choices=("bf16", "fp8"), required=True)
    parser.add_argument("--oracle-cache", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=19)
    parser.add_argument("--warmups", type=int, default=5)
    args = parser.parse_args()
    cases = json.loads(args.cases.read_text())
    ids = [c["config_id"] if isinstance(c, dict) else c for c in cases]
    expected = {
        (cid, *option)
        for cid in ids
        for option in itertools.product(
            ("identity", "permuted"), ("eager", "prepared_graph"), ("warm", "cold")
        )
    }
    args.output.mkdir(parents=True, exist_ok=True)
    selected = args.output / f"recovery-cases-{args.partial_dtype}.json"
    selected.write_text(json.dumps(ids))
    path = args.output / f"native-{args.partial_dtype}.jsonl"
    history_path = args.output / f"recovery-history-{args.partial_dtype}.json"
    history = json.loads(history_path.read_text()) if history_path.exists() else []
    while expected - recorded(path):
        before = recorded(path)
        attempt = len(history) + 1
        log = args.output / f"recovery-{args.partial_dtype}-{attempt:03d}.log"
        command = [
            sys.executable,
            str(
                Path(__file__).resolve().parents[1] / "benchmarks/bench_bs32_native.py"
            ),
            "--hf-source",
            str(args.hf_source),
            "--output",
            str(args.output),
            "--partial-dtype",
            args.partial_dtype,
            "--oracle-cache",
            str(args.oracle_cache),
            "--case-list",
            str(selected),
            "--samples",
            str(args.samples),
            "--warmups",
            str(args.warmups),
            "--resume",
        ]
        with log.open("w") as stream:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
        after = recorded(path)
        entry = {
            "attempt": attempt,
            "exit_code": result.returncode,
            "recorded_before": len(expected & before),
            "recorded_after": len(expected & after),
            "planned": len(expected),
            "log": log.name,
        }
        history.append(entry)
        history_path.write_text(json.dumps(history, indent=2))
        print(json.dumps(entry), flush=True)
        if not (expected & (after - before)):
            raise RuntimeError(f"native made no record progress; inspect {log}")


if __name__ == "__main__":
    main()

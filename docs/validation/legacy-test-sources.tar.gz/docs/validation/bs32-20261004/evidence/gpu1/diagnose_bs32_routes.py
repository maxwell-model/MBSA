#!/usr/bin/env python3
"""Replay strict routing failures and separate near ties from Attention math."""

import argparse
import bisect
import gc
import itertools
import json
from pathlib import Path

import torch

from bench_bs32_matrix import append, hf_class, make_inputs, select_cases
from mbsa import prepare_cutedsl_pipeline


def errors(actual, expected):
    diff = (actual.float() - expected.float()).abs()
    ratio = diff / (0.03 + 0.03 * expected.float().abs())
    return {
        "max_abs": float(diff.max()),
        "max_tolerance_ratio": float(ratio.max()),
        "passed": bool((ratio <= 1).all()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--oracles", type=Path, required=True)
    parser.add_argument("--hf-source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = [json.loads(line) for line in args.results.read_text().splitlines()]
    failed = {
        (r["config_id"], r["page_mapping"])
        for r in records
        if r["status"] == "failed"
        and r["partial_dtype"] == "bf16"
        and r["overlap"] == "auto"
        and r["execution"] == "eager"
        and r["l2"] == "warm"
    }
    cases = {c["config_id"]: c for c in select_cases()}
    hf = hf_class(args.hf_source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(args.output)
    for number, (cid, mapping) in enumerate(sorted(failed), 1):
        case = cases[cid]
        data = make_inputs(case, mapping)
        oracle = torch.load(
            args.oracles / f"{cid}-{mapping}.pt", map_location="cuda", weights_only=True
        )
        expected_route = torch.cat([p["route"] for p in oracle], 1)
        expected_out = torch.cat([p["out"] for p in oracle])
        pipeline = prepare_cutedsl_pipeline(
            data["iq"],
            data["ik"],
            data["q"],
            data["pool"][..., 0, :].permute(0, 2, 1, 3),
            data["pool"][..., 1, :].permute(0, 2, 1, 3),
            cu_seqlens_q=data["cu_q"],
            cu_seqlens_k=data["cu_k"],
            index_page_indices=data["pages"],
            page_table=data["table"],
            partial_dtype=torch.bfloat16,
        )
        out, _, route = pipeline.run()
        mismatches = (
            (route.sort(-1).values != expected_route.sort(-1).values)
            .any(-1)
            .nonzero()
            .tolist()
        )
        prefixes = [0] + list(itertools.accumulate(r["q"] for r in case["requests"]))
        examples = []
        for group, query in mismatches[:16]:
            slot = bisect.bisect_right(prefixes, query) - 1
            local_query = query - prefixes[slot]
            qn, kn = case["requests"][slot]["q"], case["requests"][slot]["kv"]
            ids = data["table"][slot, : data["counts"][slot]].long()
            ik = data["ik"].index_select(0, ids).reshape(-1, 128)[:kn]
            actual_ids = set(route[group, query].tolist()) - {-1}
            expected_ids = set(expected_route[group, query].tolist()) - {-1}
            missing, extra = (
                sorted(expected_ids - actual_ids),
                sorted(actual_ids - expected_ids),
            )
            # Reproduce HF's original 16-query, 8192-key FP32 GEMM geometry.
            qchunk_start = (local_query // 16) * 16
            qchunk_end = min(qn, qchunk_start + 16)
            iq_chunk = (
                data["iq"][prefixes[slot] + qchunk_start : prefixes[slot] + qchunk_end]
                .transpose(0, 1)[None]
                .float()
            )
            score_rows = []
            for block in missing + extra:
                token_start, token_end = block * 128, min(kn, (block + 1) * 128)
                chunk_start = (token_start // 8192) * 8192
                chunk_end = min(kn, chunk_start + 8192)
                scores32 = torch.einsum(
                    "bgqd,bkd->bgqk", iq_chunk, ik[None, chunk_start:chunk_end].float()
                )
                scores32.mul_(128**-0.5)
                value32 = float(
                    scores32[
                        0,
                        group,
                        local_query - qchunk_start,
                        token_start - chunk_start : token_end - chunk_start,
                    ].max()
                )
                scores64 = (
                    ik[token_start:token_end].double()
                    * data["iq"][query, group].double()
                ).sum(-1) * 128**-0.5
                value64 = float(scores64.max())
                score_rows.append(
                    {
                        "block": block,
                        "membership": "HF_only" if block in missing else "MBSA_only",
                        "HF_fp32_score": value32,
                        "fp64_score": value64,
                    }
                )
            loss32 = sum(
                x["HF_fp32_score"] for x in score_rows if x["membership"] == "HF_only"
            ) - sum(
                x["HF_fp32_score"] for x in score_rows if x["membership"] == "MBSA_only"
            )
            loss64 = sum(
                x["fp64_score"] for x in score_rows if x["membership"] == "HF_only"
            ) - sum(
                x["fp64_score"] for x in score_rows if x["membership"] == "MBSA_only"
            )
            pool = data["pool"].index_select(0, ids)
            k = pool[..., 0, :].reshape(-1, 4, 128)[:kn]
            v = pool[..., 1, :].reshape(-1, 4, 128)[:kn]
            position = torch.tensor([[kn - qn + local_query]], device="cuda")
            allowed = hf._allowed_keys(
                query_positions=position, key_len=kn, attention_mask=None
            )
            complete = hf._build_block_aligned_route(
                route[:, query : query + 1].permute(1, 0, 2)[None], position
            )
            forced = hf._sparse_attention(
                data["q"][query : query + 1].transpose(0, 1)[None],
                k.transpose(0, 1)[None],
                v.transpose(0, 1)[None],
                complete,
                allowed,
            )[0].transpose(0, 1)
            examples.append(
                {
                    "group": group,
                    "global_query": query,
                    "request": slot,
                    "request_query": local_query,
                    "missing_blocks": missing,
                    "extra_blocks": extra,
                    "scores": score_rows,
                    "selected_score_loss_fp32": loss32,
                    "selected_score_loss_fp64": loss64,
                    "HF_fp32_exact_score_sum_tie": loss32 == 0,
                    "near_tie_abs_score_loss_le_1e_5": abs(loss32) <= 1e-5,
                    "attention_vs_HF_with_MBSA_route": errors(
                        out[query : query + 1], forced
                    ),
                    "output_vs_HF_route": errors(
                        out[query : query + 1], expected_out[query : query + 1]
                    ),
                }
            )
            del pool, k, v, ik
        append(
            args.output,
            {
                "config_id": cid,
                "page_mapping": mapping,
                "total_query_heads": route.shape[0] * route.shape[1],
                "mismatched_query_heads": len(mismatches),
                "examples": examples,
                "scoring_scope": "at most 16 mismatched query/head entries per config/map; exact HF FP32 GEMM geometry plus FP64 max-dot",
            },
        )
        print(
            json.dumps(
                {
                    "case": number,
                    "of": len(failed),
                    "id": cid,
                    "mismatched_heads": len(mismatches),
                }
            ),
            flush=True,
        )
        del pipeline, data, oracle, out, route, expected_route, expected_out
        gc.collect()
        torch.cuda.empty_cache()


if __name__ == "__main__":
    main()

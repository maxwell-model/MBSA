#!/usr/bin/env python3
"""Plot bench_long_prefill.py results: MBSA chunked prefill vs dense GQA."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Labeled values from docs/images/maxwell-block-sparse-attention-performance.png.
B300_REFERENCE = {1048576: {"MBSA": 563.865, "MSA*": 503.610, "GQA": 6093.54}}


def label(n: int) -> str:
    return f"{n // 1048576}M" if n >= 1048576 else f"{n // 1024}K"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path, help="bench_long_prefill.py output")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    line = next(l for l in args.log.read_text().splitlines() if l.startswith("RESULT_JSON="))
    result = json.loads(line.split("=", 1)[1])
    rows = [r for r in result["summary"] if r["dense_gqa_ms"] is not None]
    lengths = [r["length"] for r in rows]
    mbsa = [r["mbsa_ms"] for r in rows]
    dense = [r["dense_gqa_ms"] for r in rows]

    fig, ax = plt.subplots(figsize=(10, 6.2), dpi=150)
    ax.plot(lengths, dense, "--o", color="#9ca3af", lw=2.4, label="GQA (FlashAttention-4, SM90, dense causal)")
    ax.plot(lengths, mbsa, "-o", color="#e8502e", lw=2.8, label="MBSA (CuTe DSL SM90, 8K-chunk prefill)")
    for n, d, m in zip(lengths, dense, mbsa):
        if n >= 131072:
            ax.annotate(f"{d / m:.1f}×", (n, (d * m) ** 0.5), ha="center", color="#e8502e",
                        fontsize=11, fontweight="bold")
    ax.annotate(f"{dense[-1]:,.0f} ms", (lengths[-1], dense[-1]), xytext=(-10, 8),
                textcoords="offset points", ha="right", color="#6b7280")
    ax.annotate(f"{mbsa[-1]:,.1f} ms", (lengths[-1], mbsa[-1]), xytext=(-10, 8),
                textcoords="offset points", ha="right", color="#e8502e")
    ax.set_yscale("log")
    ax.set_xscale("log", base=2)
    ax.set_xticks(lengths, [label(n) for n in lengths])
    ax.set_xlabel("Sequence length (whole-sequence prefill)")
    ax.set_ylabel("Execution time (ms, log scale)")
    ax.set_title(
        "Maxwell Block Sparse Attention on H100 (SM90)\n"
        "32 Q heads · 4 KV heads · head dim 128 · BF16", loc="left", fontsize=13
    )
    ref = B300_REFERENCE[1048576]
    ax.text(
        0.02, 0.97,
        f"B300 (SM100) reference figure @1M: MBSA {ref['MBSA']:.1f} ms, GQA {ref['GQA']:,.0f} ms"
        f" ({ref['GQA'] / ref['MBSA']:.1f}×)",
        transform=ax.transAxes, va="top", fontsize=9, color="#374151",
    )
    ax.grid(True, which="both", ls=":", alpha=0.5)
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(args.output)
    print(args.output)


if __name__ == "__main__":
    main()

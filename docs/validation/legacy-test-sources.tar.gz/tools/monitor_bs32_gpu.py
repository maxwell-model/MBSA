#!/usr/bin/env python3
"""Record host GPU occupancy without creating a CUDA context."""

import argparse
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path


def run(*command):
    return subprocess.check_output(command, text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gpu", type=int, required=True)
    parser.add_argument("--container", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stop-file", type=Path, required=True)
    args = parser.parse_args()
    container_id = run("docker", "inspect", "--format", "{{.Id}}", args.container)
    uuid = run(
        "nvidia-smi", "-i", str(args.gpu), "--query-gpu=uuid", "--format=csv,noheader"
    )
    while not args.stop_file.exists():
        record = {
            "utc": datetime.now(timezone.utc).isoformat(),
            "gpu": args.gpu,
            "uuid": uuid,
        }
        try:
            record["gpu_fields"] = (
                "memory.used,memory.free,utilization.gpu,clocks.sm,temperature.gpu,power.draw"
            )
            record["gpu_values"] = run(
                "nvidia-smi",
                "-i",
                str(args.gpu),
                "--query-gpu=" + record["gpu_fields"],
                "--format=csv,noheader,nounits",
            )
            processes = []
            for row in run(
                "nvidia-smi",
                "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
                "--format=csv,noheader,nounits",
            ).splitlines():
                fields = [x.strip() for x in row.split(",")]
                if fields[0] != uuid:
                    continue
                try:
                    cgroup = Path(f"/proc/{fields[1]}/cgroup").read_text()
                    owned = container_id in cgroup
                except FileNotFoundError:
                    owned = None  # A process may exit between the two reads.
                processes.append(
                    {
                        "pid": fields[1],
                        "name": fields[2],
                        "memory_mib": fields[3],
                        "test_container": owned,
                    }
                )
            record["processes"] = processes
            record["foreign_process_count"] = sum(
                p["test_container"] is False for p in processes
            )
        except Exception as exc:
            record["error"] = str(exc)
        with args.output.open("a") as f:
            f.write(json.dumps(record) + "\n")
        time.sleep(30)


if __name__ == "__main__":
    main()

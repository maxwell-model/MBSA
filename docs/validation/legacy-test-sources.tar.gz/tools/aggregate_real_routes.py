#!/usr/bin/env python3
"""Quantify previously oracle-verified full real-layer routing captures on CPU."""

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import torch


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    records = []
    totals = {}
    for dtype in ("bf16", "fp8"):
        totals[dtype] = Counter()
        for path in sorted((args.root / f"divergence-full-{dtype}").glob("*.pt")):
            verified_path = path.with_name(path.stem + "-oracle.json")
            verified = json.loads(verified_path.read_text())
            if (
                verified["remote_route_set_match_fraction"] != 1.0
                or not verified["mbsa_vs_oracle"]["passed"]
            ):
                raise ValueError(f"capture is not fully oracle verified: {path}")
            data = torch.load(path, map_location="cpu", weights_only=True)
            # The captured MBSA route is independently proven equal to the
            # pinned HF-derived Python route at every query of this chunk.
            expected, actual = data["route"], data["native_route"]
            match = (expected.sort(-1).values == actual.sort(-1).values).all(-1)
            intersection = (
                (
                    (actual[..., :, None] == expected[..., None, :])
                    & (actual[..., :, None] >= 0)
                )
                .any(-1)
                .sum(-1)
            )
            missing = (expected >= 0).sum(-1) - intersection
            extra = (actual >= 0).sum(-1) - intersection
            row = {
                "dtype": dtype,
                "capture": path.name,
                "request": data["request"],
                "query_head_count": match.numel(),
                "mismatched_query_heads": int((~match).sum()),
                "missing_blocks": int(missing.sum()),
                "extra_blocks": int(extra.sum()),
                "expected_valid_blocks": int((expected >= 0).sum()),
                "intersection_blocks": int(intersection.sum()),
                "missing_blocks_per_query_head_distribution": dict(
                    Counter(missing.flatten().tolist())
                ),
                "max_missing_blocks_per_query_head": int(missing.max()),
                "max_extra_blocks_per_query_head": int(extra.max()),
                "mbsa_vs_hf_derived_oracle": verified["mbsa_vs_oracle"],
                "native_vs_hf_derived_oracle": verified["native_vs_oracle"],
                "capture_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "verification_sha256": hashlib.sha256(
                    verified_path.read_bytes()
                ).hexdigest(),
            }
            records.append(row)
            for key in (
                "query_head_count",
                "mismatched_query_heads",
                "missing_blocks",
                "extra_blocks",
                "expected_valid_blocks",
                "intersection_blocks",
            ):
                totals[dtype][key] += row[key]
            for key in (
                "max_missing_blocks_per_query_head",
                "max_extra_blocks_per_query_head",
            ):
                totals[dtype][key] = max(totals[dtype][key], row[key])
            del data
    args.output.write_text(
        json.dumps(
            {
                "kind": "historical_real_layer_full_chunk_route_counts",
                "scope": "2026-10-03 recorded four-layer chunks; not new BS32 timing samples",
                "expected_route": "captured MBSA route previously verified equal to pinned HF-derived Python for all queries",
                "totals": totals,
                "records": records,
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(totals), flush=True)


if __name__ == "__main__":
    main()

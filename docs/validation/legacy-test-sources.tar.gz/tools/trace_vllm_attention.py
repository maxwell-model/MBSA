#!/usr/bin/env python3
"""Collect serving Attention shapes from an eager vLLM workload.

This deliberately synchronizes metadata during tracing. Timing belongs to a
separate replay run; trace collection is not a performance measurement.
"""

from __future__ import annotations

import argparse
from collections import Counter
import faulthandler
import functools
import hashlib
import importlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import signal
import statistics
import time


class ShapeTrace:
    def __init__(self):
        self.phase = "warmup"
        self.records = Counter()
        self.sources = {}
        self.originals = []
        self.comparisons = []
        self.logprobs = []
        self.native_generations = []
        self.native_logprobs = []
        self.cached_generations = []
        self.mbsa_dispatches = Counter()
        self.enabled = True
        self.throughput = {}

    def install(self):
        # Literal module names identify the existing upstream/baseline APIs.
        candidates = (
            "vllm.model_executor.layers.maxwell_moe_bsa",
            "vllm.model_executor.layers.maxwell_v1_bsa",
            "vllm.model_executor.layers.compass_bsa",
        )
        for name in candidates:
            if importlib.util.find_spec(name) is None:
                continue
            module = importlib.import_module(name)
            source = Path(module.__file__)
            self.sources[name] = {
                "path": str(source),
                "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            }
            for _, cls in inspect.getmembers(module, inspect.isclass):
                if cls.__module__ != name:
                    continue
                for method in (
                    "prefill_unified",
                    "prefill",
                    "prefill_csr_graph",
                    "decode_triton",
                ):
                    if method in cls.__dict__:
                        self.wrap(cls, method)
        if not self.originals:
            raise RuntimeError(
                "No supported vLLM sparse Attention implementation found"
            )

    def wrap(self, cls, method):
        original = getattr(cls, method)
        signature = inspect.signature(original)

        @functools.wraps(original)
        def wrapped(*args, **kwargs):
            if not self.enabled:
                return original(*args, **kwargs)
            bound = signature.bind(*args, **kwargs)
            bound.apply_defaults()
            values = bound.arguments
            # Graph replay does not invoke Python hooks. Capture records omit
            # device-to-host metadata reads, which CUDA capture forbids.
            import torch

            capturing = torch.cuda.is_current_stream_capturing()
            record = {
                "phase": self.phase,
                "method": method,
                "module": cls.__module__,
                "capture": capturing,
            }
            for tensor_name in (
                "q",
                "key_cache",
                "value_cache",
                "index_q",
                "index_k_cache",
                "page_table",
                "selection",
            ):
                tensor = values.get(tensor_name)
                if isinstance(tensor, torch.Tensor):
                    record[tensor_name] = {
                        "shape": list(tensor.shape),
                        "stride": list(tensor.stride()),
                        "dtype": str(tensor.dtype),
                    }
            request_lens = values.get("request_lens")
            if request_lens is not None:
                record["requests"] = [list(pair) for pair in request_lens]
            elif not capturing:
                seq_lens = values.get("seq_lens")
                cu_q = values.get("cu_seqlens_q")
                if isinstance(seq_lens, torch.Tensor):
                    kv_lens = seq_lens.detach().cpu().tolist()
                    if isinstance(cu_q, torch.Tensor):
                        prefix = cu_q.detach().cpu().tolist()
                        q_lens = [b - a for a, b in zip(prefix, prefix[1:])]
                    else:
                        q_lens = [values.get("decode_query_len", 1)] * len(kv_lens)
                    record["requests"] = [
                        [qn, kn] for qn, kn in zip(q_lens, kv_lens) if qn > 0 and kn > 0
                    ]
            record["decode_query_len"] = values.get("decode_query_len")
            owner = values.get("self")
            record["partial_dtype"] = str(
                getattr(
                    owner,
                    "prefill_partial_dtype",
                    getattr(owner, "partial_dtype", None),
                )
            )
            record["index_q_scales"] = values.get("index_q_scales") is not None
            result = original(*args, **kwargs)
            record["served"] = result is not None
            self.records[json.dumps(record, sort_keys=True)] += 1
            return result

        self.originals.append((cls, method, original))
        setattr(cls, method, wrapped)

    def save(self, output, config, generations, error):
        output.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema": 1,
            "kind": "actual_vllm_attention_calls",
            "config": config,
            "sources": self.sources,
            "records": [
                dict(json.loads(key), calls=count)
                for key, count in self.records.items()
            ],
            "generations": generations,
            "error": error,
            "attention_comparisons": self.comparisons,
            "generation_logprobs": self.logprobs,
            "native_generations": self.native_generations,
            "native_generation_logprobs": self.native_logprobs,
            "cached_generations": self.cached_generations,
            "mbsa_dispatches": dict(self.mbsa_dispatches),
            "throughput": self.throughput,
        }
        output.write_text(json.dumps(payload, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--prompt-lengths", type=int, nargs="+", default=[129, 4097, 8193]
    )
    parser.add_argument("--max-model-len", type=int, default=16384)
    parser.add_argument("--budget", type=int, default=8192)
    parser.add_argument("--decode-steps", type=int, default=4)
    parser.add_argument("--logprobs", type=int, default=5)
    parser.add_argument(
        "--throughput-samples",
        type=int,
        default=0,
        help="Alternate native/MBSA generation timing with tracing/logprobs off",
    )
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.03)
    parser.add_argument("--load-format", default="auto")
    parser.add_argument("--dump-divergence", type=Path)
    parser.add_argument(
        "--dump-full-divergence",
        action="store_true",
        help="Save all queries of each failing request/layer for a full oracle check",
    )
    parser.add_argument("--prefix-cache", action="store_true")
    parser.add_argument(
        "--serving-graphs",
        action="store_true",
        help="Allow native serving graphs; graph replays do not execute Python hooks",
    )
    parser.add_argument(
        "--mbsa-warmup",
        action="store_true",
        help="Also dispatch MBSA during startup warmup (eager qualification)",
    )
    parser.add_argument(
        "--mbsa",
        action="store_true",
        help="Use the MBSA eager adapter through an isolated runtime hook",
    )
    parser.add_argument(
        "--compare-native",
        action="store_true",
        help="Compare real layer outputs before returning MBSA output",
    )
    parser.add_argument(
        "--compare-generations",
        action="store_true",
        help="Run the same prompts again through native prefill for token/logprob comparison",
    )
    parser.add_argument("--hf-overrides", type=json.loads, default={})
    args = parser.parse_args()
    if any(
        n <= 0 or n + args.decode_steps > args.max_model_len
        for n in args.prompt_lengths
    ):
        parser.error("prompt lengths must be positive and fit within max-model-len")
    faulthandler.enable()
    faulthandler.register(signal.SIGUSR1, all_threads=True)
    os.environ["VLLM_ENABLE_V1_MULTIPROCESSING"] = "0"
    import vllm
    from vllm import LLM, SamplingParams

    trace = ShapeTrace()
    trace.install()
    if args.mbsa:
        from mbsa.vllm import prefill

        # Preserve the instrumented signature and upstream installation. The
        # hook is local to this validation process and leaves decode intact.
        backend_source = Path(inspect.getfile(prefill))
        trace.sources["mbsa.vllm"] = {
            "path": str(backend_source),
            "sha256": hashlib.sha256(backend_source.read_bytes()).hexdigest(),
        }
        for cls, method, native in tuple(trace.originals):
            if method != "prefill_unified":
                continue
            instrumented = native
            signature = inspect.signature(native)

            def make_dispatch(instrumented, signature):
                @functools.wraps(instrumented)
                def dispatch(*positional, **kwargs):
                    if trace.phase in ("serving_native", "benchmark_native") or (
                        trace.phase == "warmup" and not args.mbsa_warmup
                    ):
                        return instrumented(*positional, **kwargs)
                    values = signature.bind(*positional, **kwargs).arguments
                    owner = values.pop("self")
                    expected = None
                    expected_route = None
                    if args.compare_native and trace.enabled:
                        reference = instrumented(*positional, **kwargs)
                        if reference is not None:
                            expected = reference.clone()
                            if args.dump_divergence is not None:
                                module = importlib.import_module(type(owner).__module__)
                                storages = getattr(
                                    module, "_UNIFIED_PREFILL_STORAGE", {}
                                )
                                storage = storages.get(values["q"].device.index)
                                route_view = getattr(
                                    module, "unified_prefill_dynamic_route", None
                                )
                                if storage is not None and route_view is not None:
                                    expected_route = route_view(
                                        storage, values["q"].shape[0]
                                    ).clone()
                    trace.mbsa_dispatches[trace.phase] += 1
                    if trace.phase == "warmup":
                        print(
                            "MBSA warmup",
                            trace.mbsa_dispatches[trace.phase],
                            values.get("request_lens"),
                            flush=True,
                        )
                    actual = prefill(
                        **values, partial_dtype=owner.prefill_partial_dtype
                    )
                    if expected is not None:
                        import torch

                        offset = 0
                        for slot, (qn, kn) in enumerate(values["request_lens"]):
                            if qn <= 0:
                                continue
                            candidate = actual[offset : offset + qn].float()
                            baseline = expected[offset : offset + qn].float()
                            diff = (candidate - baseline).abs()
                            trace.comparisons.append(
                                {
                                    "phase": trace.phase,
                                    "request": [qn, kn],
                                    "max_abs_error": diff.max().item(),
                                    "rms_error": diff.square().mean().sqrt().item(),
                                    "baseline_rms": baseline.square()
                                    .mean()
                                    .sqrt()
                                    .item(),
                                    "close_fraction": torch.isclose(
                                        candidate, baseline, rtol=0.03, atol=0.03
                                    )
                                    .float()
                                    .mean()
                                    .item(),
                                }
                            )
                            if (
                                args.dump_divergence is not None
                                and trace.phase.startswith("serving")
                                and not torch.all(
                                    torch.isclose(
                                        candidate, baseline, rtol=0.03, atol=0.03
                                    )
                                )
                            ):
                                destination = args.dump_divergence / (
                                    f"{trace.phase}-{qn}-{kn}-"
                                    f"{trace.mbsa_dispatches[trace.phase]}.pt"
                                )
                                if not destination.exists():
                                    destination.parent.mkdir(
                                        parents=True, exist_ok=True
                                    )
                                    count = (kn + 127) // 128
                                    ids = values["page_table"][slot, :count].long()
                                    counts = [
                                        (n + 127) // 128
                                        for _, n in values["request_lens"]
                                    ]
                                    mapping = values["index_page_indices"]
                                    if mapping.ndim == 2:
                                        index_ids = mapping[slot, :count]
                                    elif mapping.numel() == sum(counts):
                                        begin = sum(counts[:slot])
                                        index_ids = mapping[begin : begin + count]
                                    else:
                                        index_ids = mapping.view(len(counts), -1)[
                                            slot, :count
                                        ]
                                    # Capture the worst query, rather than the first
                                    # tolerance crossing (which may hide the bug).
                                    worst = int(diff.flatten(1).amax(1).argmax())
                                    begin = (worst // 16) * 16
                                    end = min(begin + 16, qn)
                                    if args.dump_full_divergence:
                                        begin, end = 0, qn
                                    qs = slice(offset + begin, offset + end)
                                    from mbsa.vllm import _ADAPTERS

                                    graph_mode = os.environ.get(
                                        "MBSA_VLLM_PREFILL_GRAPH", "0"
                                    )
                                    adapter = _ADAPTERS[actual.device, graph_mode]
                                    pipeline = next(reversed(adapter.plans.values()))
                                    operands = {
                                        "index_q": values["index_q"][qs],
                                        "index_k": values["index_k_cache"][
                                            index_ids.long()
                                        ].reshape(-1, 1, 128)[:kn],
                                        "q": values["q"][qs],
                                        "k": values["key_cache"][ids].reshape(
                                            -1, 4, 128
                                        )[:kn],
                                        "v": values["value_cache"][ids].reshape(
                                            -1, 4, 128
                                        )[:kn],
                                        "actual": actual[qs],
                                        "native": expected[qs],
                                        "route": pipeline.plan.attention.tile_plan.dynamic_route[
                                            :, qs
                                        ],
                                    }
                                    if expected_route is not None:
                                        operands["native_route"] = expected_route[:, qs]
                                    dump = {
                                        name: tensor.detach().cpu()
                                        for name, tensor in operands.items()
                                    }
                                    dump.update(
                                        request=[qn, kn],
                                        query_offset=kn - qn + begin,
                                        phase=trace.phase,
                                        comparison=trace.comparisons[-1],
                                    )
                                    torch.save(dump, destination)
                            offset += qn
                    return actual

                return dispatch

            # Replace the original called by the trace wrapper, then reinstall
            # instrumentation around the replacement so real MBSA calls count.
            setattr(cls, method, make_dispatch(instrumented, signature))
            trace.wrap(cls, method)
    generations = []
    error = None
    try:
        model = LLM(
            model=args.model,
            enforce_eager=not args.serving_graphs,
            trust_remote_code=True,
            max_model_len=args.max_model_len,
            max_num_batched_tokens=args.budget,
            max_num_seqs=len(args.prompt_lengths),
            enable_chunked_prefill=True,
            enable_prefix_caching=args.prefix_cache,
            gpu_memory_utilization=args.gpu_memory_utilization,
            load_format=args.load_format,
            hf_overrides=args.hf_overrides,
        )
        trace.phase = "serving"
        prompts = [
            {"prompt_token_ids": [128 + i % 127 for i in range(n)]}
            for n in args.prompt_lengths
        ]
        outputs = model.generate(
            prompts,
            SamplingParams(
                temperature=0,
                max_tokens=args.decode_steps,
                ignore_eos=True,
                logprobs=args.logprobs,
            ),
            use_tqdm=False,
        )
        generations = [list(output.outputs[0].token_ids) for output in outputs]
        trace.logprobs = [
            [
                {
                    str(token): {"logprob": value.logprob, "rank": value.rank}
                    for token, value in step.items()
                }
                for step in output.outputs[0].logprobs
            ]
            for output in outputs
        ]
        if args.compare_generations:
            if not args.mbsa or args.prefix_cache:
                raise ValueError(
                    "generation comparison requires --mbsa and prefix caching off"
                )
            trace.phase = "serving_native"
            native_outputs = model.generate(
                prompts,
                SamplingParams(
                    temperature=0,
                    max_tokens=args.decode_steps,
                    ignore_eos=True,
                    logprobs=args.logprobs,
                ),
                use_tqdm=False,
            )
            trace.native_generations = [
                list(output.outputs[0].token_ids) for output in native_outputs
            ]
            trace.native_logprobs = [
                [
                    {
                        str(token): {"logprob": value.logprob, "rank": value.rank}
                        for token, value in step.items()
                    }
                    for step in output.outputs[0].logprobs
                ]
                for output in native_outputs
            ]
        if args.prefix_cache:
            trace.phase = "serving_cached"
            cached_outputs = model.generate(
                prompts,
                SamplingParams(
                    temperature=0, max_tokens=args.decode_steps, ignore_eos=True
                ),
                use_tqdm=False,
            )
            trace.cached_generations = [
                list(output.outputs[0].token_ids) for output in cached_outputs
            ]
        if args.throughput_samples:
            if not args.mbsa or args.prefix_cache:
                raise ValueError(
                    "throughput A/B requires --mbsa and prefix caching off"
                )
            import torch

            trace.enabled = False
            params = SamplingParams(
                temperature=0, max_tokens=args.decode_steps, ignore_eos=True
            )
            measured = {name: [] for name in ("native", "mbsa")}
            for name in measured:
                trace.phase = "benchmark_" + name
                model.generate(prompts, params, use_tqdm=False)
            for sample in range(args.throughput_samples):
                order = list(measured)
                if sample % 2:
                    order.reverse()
                for name in order:
                    trace.phase = "benchmark_" + name
                    torch.cuda.synchronize()
                    begin = time.perf_counter()
                    result = model.generate(prompts, params, use_tqdm=False)
                    torch.cuda.synchronize()
                    elapsed = time.perf_counter() - begin
                    measured[name].append(
                        {
                            "elapsed_s": elapsed,
                            "tokens": [list(r.outputs[0].token_ids) for r in result],
                        }
                    )
            for name, samples in measured.items():
                median = statistics.median(s["elapsed_s"] for s in samples)
                trace.throughput[name] = {
                    "median_s": median,
                    "input_tokens_per_s": sum(args.prompt_lengths) / median,
                    "output_tokens_per_s": len(prompts) * args.decode_steps / median,
                    "samples": samples,
                }
            trace.enabled = True
        if not any(json.loads(key)["phase"] == "serving" for key in trace.records):
            raise RuntimeError("No real serving Attention calls were captured")
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        config = vars(args).copy()
        config["output"] = str(args.output)
        if config["dump_divergence"] is not None:
            config["dump_divergence"] = str(config["dump_divergence"])
        config["vllm_version"] = vllm.__version__
        config["trace_enforce_eager"] = not args.serving_graphs
        config["backend_environment"] = {
            name: os.environ.get(name)
            for name in (
                "MAXWELL_INDEX_FORMAT",
                "MAXWELL_BSA_PREFILL_FP8_PARTIALS",
                "MAXWELL_PREFILL",
                "MBSA_VLLM_PREFILL_GRAPH",
                "MBSA_FP8_PARTIAL_OUT",
            )
        }
        trace.save(args.output, config, generations, error)


if __name__ == "__main__":
    main()

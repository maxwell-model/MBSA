#!/usr/bin/env python3
"""Check a real-layer divergence dump against the retained Python oracle."""

import argparse
import json
from pathlib import Path

import torch

from mbsa.reference import MaxwellBlockSparseAttentionReference, reference_pipeline


def errors(actual, expected):
    actual, expected = actual.float(), expected.float()
    delta = (actual - expected).abs()
    return {
        "passed": torch.isclose(actual, expected, atol=0.03, rtol=0.03).all().item(),
        "max_abs_error": delta.max().item(),
        "rms_error": delta.square().mean().sqrt().item(),
        "close_fraction": torch.isclose(actual, expected, atol=0.03, rtol=0.03)
        .float()
        .mean()
        .item(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dump", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    dump = torch.load(args.dump, map_location="cuda", weights_only=True)
    iq, ik, q, k, v = (dump[name] for name in ("index_q", "index_k", "q", "k", "v"))
    offset = dump["query_offset"]
    expected, _, route = reference_pipeline(iq, ik, q, k, v, query_offset=offset)
    oracle = MaxwellBlockSparseAttentionReference(index_head_dim=128, head_dim=128)
    positions = torch.arange(offset, offset + q.shape[0], device=q.device)[None]
    allowed = oracle._allowed_keys(
        query_positions=positions, key_len=k.shape[0], attention_mask=None
    )
    complete = oracle._build_block_aligned_route(
        dump["route"].permute(1, 0, 2)[None].long(), positions
    )
    forced = oracle._sparse_attention(
        q.transpose(0, 1)[None],
        k.transpose(0, 1)[None],
        v.transpose(0, 1)[None],
        complete,
        allowed,
    )[0].transpose(0, 1)
    same = dump["route"].sort(-1).values.eq(route.sort(-1).values).all(-1)
    report = {
        "dump": str(args.dump),
        "request": dump["request"],
        "query_offset": offset,
        "query_count": q.shape[0],
        "mbsa_vs_oracle": errors(dump["actual"], expected),
        "native_vs_oracle": errors(dump["native"], expected),
        "mbsa_vs_oracle_with_mbsa_route": errors(dump["actual"], forced),
        "native_vs_oracle_with_mbsa_route": errors(dump["native"], forced),
        "remote_route_set_match_fraction": same.float().mean().item(),
        "route_mismatches": [],
    }
    for group, query in (~same).nonzero().tolist()[:8]:
        report["route_mismatches"].append(
            {
                "group": group,
                "query": query,
                "mbsa": dump["route"][group, query].tolist(),
                "oracle": route[group, query].tolist(),
            }
        )
    if "native_route" in dump:
        native_route = dump["native_route"]
        native_same = native_route.sort(-1).values.eq(route.sort(-1).values).all(-1)
        report["native_remote_route_set_match_fraction"] = (
            native_same.float().mean().item()
        )
        report["native_route_mismatches"] = []
        token_scores = (
            torch.einsum("qgd,kd->gqk", iq.float(), ik[:, 0].float()) * 128**-0.5
        )
        token_scores = torch.nn.functional.pad(
            token_scores, (0, (-k.shape[0]) % 128), value=-torch.inf
        )
        block_scores = token_scores.view(4, q.shape[0], -1, 128).amax(-1)
        for group, query in (~native_same).nonzero().tolist()[:8]:
            native_ids = set(native_route[group, query].tolist()) - {-1}
            oracle_ids = set(route[group, query].tolist()) - {-1}
            added, omitted = (
                sorted(native_ids - oracle_ids),
                sorted(oracle_ids - native_ids),
            )
            report["native_route_mismatches"].append(
                {
                    "group": group,
                    "query": query,
                    "native_added": added,
                    "native_omitted": omitted,
                    "added_scores": block_scores[group, query, added].tolist(),
                    "omitted_scores": block_scores[group, query, omitted].tolist(),
                }
            )
        complete = oracle._build_block_aligned_route(
            native_route.permute(1, 0, 2)[None].long(), positions
        )
        native_forced = oracle._sparse_attention(
            q.transpose(0, 1)[None],
            k.transpose(0, 1)[None],
            v.transpose(0, 1)[None],
            complete,
            allowed,
        )[0].transpose(0, 1)
        report["native_vs_oracle_with_native_route"] = errors(
            dump["native"], native_forced
        )
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
    if not report["mbsa_vs_oracle"]["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

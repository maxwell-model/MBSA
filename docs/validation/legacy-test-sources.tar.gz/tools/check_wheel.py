"""Check a built wheel's isolated imports, CPU oracle and shipped CUDA sources."""

from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("wheel", type=Path)
    args = parser.parse_args()
    required = (
        "mbsa/_vendor/msa/LICENSE",
        "mbsa/_vendor/msa/NOTICE",
        "mbsa/_vendor/anthony_bsa_backend/LICENSE",
        "mbsa/_vendor/anthony_bsa_backend/NOTICE",
        "mbsa/_vendor/msa/python/fmha_sm100/cute/src/sm100/build_k2q_csr/build_k2q_csr.cu",
    )
    with zipfile.ZipFile(args.wheel) as wheel, tempfile.TemporaryDirectory() as folder:
        names = set(wheel.namelist())
        missing = set(required) - names
        if missing:
            raise SystemExit(f"Wheel is missing runtime data: {sorted(missing)}")
        wheel.extractall(folder)
        script = r"""
import pathlib, sys
root = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
import mbsa
assert pathlib.Path(mbsa.__file__).resolve().is_relative_to(root)
assert not {'torch', 'triton', 'cutlass', 'fmha_sm100'}.intersection(sys.modules)
import mbsa._vendor.msa.python.fmha_sm100 as bundled
assert pathlib.Path(bundled.__file__).resolve().is_relative_to(root)
assert 'fmha_sm100' not in sys.modules
from mbsa import reference_pipeline, prepare_cutedsl_pipeline
import torch
q = torch.zeros((1, 2, 4))
k = torch.zeros((7, 1, 4))
v = torch.arange(28).reshape(7, 1, 4).float()
output, lse, route = reference_pipeline(
    torch.ones((1, 1, 4)), torch.ones((7, 1, 4)), q, k, v,
    block_size=2, dynamic_topk=4, prefix_blocks=1, local_blocks=1,
)
torch.testing.assert_close(output[0, 0], v[:, 0].mean(0))
torch.testing.assert_close(lse, torch.full((1, 2), 7.0).log())
assert route.shape == (1, 1, 4)
try:
    prepare_cutedsl_pipeline(q, k, q, k, v)
except ValueError as error:
    assert 'CUDA' in str(error)
else:
    raise AssertionError('CuTe DSL must reject CPU tensors')
assert 'cutlass' not in sys.modules and 'fmha_sm100' not in sys.modules
print('Wheel check passed: isolated CPU imports, oracle, licenses and CUDA runtime sources')
"""
        subprocess.run(
            [sys.executable, "-I", "-c", script, folder], cwd=folder, check=True
        )


if __name__ == "__main__":
    main()

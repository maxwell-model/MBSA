#!/usr/bin/env python3
"""Summarize a BS32 matrix run and pair it with a reference run (e.g. B300).

Reads results.jsonl files written by benchmarks/bench_bs32_matrix.py (one
or more shard directories), checks coverage, aggregates precision gates and
route differences, and compares option-matched latencies with a reference.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path

KEY = ("config_id", "partial_dtype", "page_mapping", "overlap", "execution", "l2")
ROUTE_FIELDS = (
    "query_head_count",
    "mismatched_query_heads",
    "missing_blocks",
    "extra_blocks",
    "expected_valid_blocks",
)


def read(path: Path) -> list[dict]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt") as f:
        return [json.loads(line) for line in f if line.strip()]


def load(paths: list[Path]) -> dict[tuple, dict]:
    records = {}
    for path in paths:
        files = sorted(path.rglob("results.jsonl")) if path.is_dir() else [path]
        for file in files:
            for r in read(file):
                records[tuple(r[k] for k in KEY)] = r
    return records


def geomean(values):
    return math.exp(statistics.mean(math.log(v) for v in values)) if values else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, nargs="+", required=True)
    parser.add_argument("--cases", type=Path, required=True, help="selected-cases.json")
    parser.add_argument("--reference", type=Path, help="reference results.jsonl[.gz]")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = load(args.results)
    cases = json.loads(args.cases.read_text())
    planned = len(cases) * 48
    status = Counter(r["status"] for r in records.values())
    measured = [r for r in records.values() if "precision" in r]

    # Precision: one eager/warm record per (config, dtype, mapping, overlap).
    by_dtype = defaultdict(lambda: Counter())
    worst = defaultdict(lambda: {"output_max_abs": 0.0, "output_max_tolerance_ratio": 0.0,
                                 "lse_max_abs": 0.0, "lse_max_tolerance_ratio": 0.0})
    checked = defaultdict(int)
    failed_configs = defaultdict(set)
    for r in measured:
        if (r["execution"], r["l2"]) != ("eager", "warm"):
            continue
        p, dtype = r["precision"], r["partial_dtype"]
        if r["page_mapping"] == "identity" and r["overlap"] == "auto":
            for field in ROUTE_FIELDS:
                by_dtype[dtype][field] += p["route"][field]
            checked[dtype] += p["checked_queries"]
        for field in worst[dtype]:
            worst[dtype][field] = max(worst[dtype][field], p[field])
        if r["status"] != "passed":
            failed_configs[dtype].add(r["config_id"])

    errors = [
        {k: r.get(k) for k in KEY + ("status", "exception")}
        for r in records.values()
        if r["status"] not in ("passed", "failed")
    ]
    timing = defaultdict(list)
    for r in measured:
        timing[r["partial_dtype"], r["execution"], r["l2"], r["overlap"]].append(
            r["timing"]["gpu_median_ms"]
        )
    summary = {
        "selected_configs": len(cases),
        "planned_records": planned,
        "actual_records": len(records),
        "missing_records": planned - len(records),
        "status": dict(status),
        "errors": errors[:50],
        "routes_identity_auto": {d: dict(c) | {"checked_queries": checked[d]} for d, c in by_dtype.items()},
        "worst_precision": dict(worst),
        "configs_with_strict_gate_failures": {d: sorted(v) for d, v in failed_configs.items()},
        "latency_sum_ms": {
            "|".join(k): sum(v) for k, v in sorted(timing.items())
        },
    }
    if args.reference:
        reference = {tuple(r[k] for k in KEY): r for r in read(args.reference)}
        ratios = defaultdict(list)
        pairs = []
        for key, r in records.items():
            ref = reference.get(key)
            if ref is None or "timing" not in r or "timing" not in ref:
                continue
            ratio = r["timing"]["gpu_median_ms"] / ref["timing"]["gpu_median_ms"]
            ratios[key[1], key[4], key[5]].append(ratio)
            pairs.append(ratio)
        status_pairs = Counter(
            (r["status"], reference[k]["status"]) for k, r in records.items() if k in reference
        )
        summary["reference_comparison"] = {
            "paired_records": len(pairs),
            "time_ratio_vs_reference_geomean": geomean(pairs),
            "time_ratio_vs_reference_median": statistics.median(pairs) if pairs else None,
            "by_dtype_execution_l2": {
                "|".join(k): {"pairs": len(v), "geomean": geomean(v), "median": statistics.median(v)}
                for k, v in sorted(ratios.items())
            },
            "status_pairs": {f"{a}/{b}": n for (a, b), n in status_pairs.items()},
        }
    args.output.write_text(json.dumps(summary, indent=2))
    print(json.dumps({k: summary[k] for k in ("actual_records", "missing_records", "status")}))


if __name__ == "__main__":
    main()

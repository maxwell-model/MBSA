"""Generate the editable draw.io Attention diagram and its SVG preview.

Run from any directory with matplotlib installed. To refresh the PNG,
install resvg-py and pass --png.
All operators, connectors, tensor stacks and mask blocks are native mxCells.
"""

from __future__ import annotations

import argparse
from html import escape
from io import BytesIO
from pathlib import Path
import xml.etree.ElementTree as ET

WIDTH, HEIGHT = 1930, 820

OUTPUT = Path(__file__).resolve().parents[1] / "docs/images" / "maxwell-block-sparse-attention-structure"
INK, BORDER, EDGE = "#34383D", "#C9CED4", "#9299A2"
PALE, INDEX, MAIN, SELECTED = "#FBFBFC", "#ffffff", "#F2F5F8", "#EE4D2D"
IMPORTANT = "#FFF6F1"
PREFIX, SWA, REMOTE = SELECTED, "#F0B34F", "#ABB1BA"
FONT_FAMILY = "Times New Roman"
MATH_FAMILY = "Times New Roman"
FIXED_FILL, FIXED_BORDER = "#FFF9F5", "#DCC8BD"
SPARSE_FILL = "#FFECE3"


def generate(png: bool = False) -> None:
    mxfile = ET.Element("mxfile", {"host": "app.diagrams.net", "version": "26.0.0"})
    diagram = ET.SubElement(
        mxfile, "diagram", {"id": "mbsa-attention", "name": "Maxwell Block Sparse Attention"}
    )
    graph = ET.SubElement(
        diagram,
        "mxGraphModel",
        {
            "dx": str(WIDTH),
            "dy": str(HEIGHT),
            "grid": "1",
            "gridSize": "10",
            "guides": "1",
            "tooltips": "1",
            "connect": "1",
            "arrows": "1",
            "fold": "1",
            "page": "1",
            "pageScale": "1",
            "pageWidth": str(WIDTH),
            "pageHeight": str(HEIGHT),
            "math": "1",
            "shadow": "0",
        },
    )
    root = ET.SubElement(graph, "root")
    ET.SubElement(root, "mxCell", {"id": "0"})
    ET.SubElement(root, "mxCell", {"id": "1", "parent": "0"})
    layers: dict[str, list[str]] = {
        name: [] for name in ("frames", "edges", "nodes", "labels")
    }
    positions: dict[str, tuple[float, float, float, float]] = {}
    serial = 0

    def node(
        name,
        x,
        y,
        w,
        h,
        lines=(),
        *,
        fill=INDEX,
        stroke=BORDER,
        font=22,
        math_font=None,
        bold=None,
        radius=13,
        layer="nodes",
        html=None,
        important=False,
    ):
        if math_font is not None:
            math_font *= 0.9
        positions[name] = (x, y, w, h)
        if bold is None:
            bold = name in {
                "output-projection", "state-merge", "block-max",
                "fixed-attention", "dynamic-attention", "index-score",
                "selected-kv", "index-norm-rope", "main-norm-rope",
                "index-projection", "main-projection", "mask-title",
            }
        if important:
            stroke = "#E8AB97"
        style = (
            f"rounded={int(radius > 0)};absoluteArcSize=1;arcSize={radius*2};whiteSpace=wrap;html=1;"
            f"fillColor={fill};strokeColor={stroke};strokeWidth=1.2;"
            f"fontColor={INK};fontFamily={FONT_FAMILY};fontSize={font};"
            f"fontStyle={int(bold)};align=center;verticalAlign=middle;spacing=4;"
        )
        value = (
            html
            if html is not None
            else "<br>".join(
                (
                    f'<span style="font-size:{math_font}px">'
                    + escape(r"\(" + s[1:-1] + r"\)")
                    + "</span>"
                    if math_font is not None
                    else escape(r"\(" + s[1:-1] + r"\)")
                )
                if s.startswith("$") and s.endswith("$")
                else (f'<span style="font-weight:normal">{escape(s)}</span>'
                      if bold and i > 0 else escape(s))
                for i, s in enumerate(lines)
            )
        )
        cell = ET.SubElement(
            root,
            "mxCell",
            {"id": name, "value": value, "style": style, "vertex": "1", "parent": "1"},
        )
        ET.SubElement(
            cell,
            "mxGeometry",
            {
                "x": str(x),
                "y": str(y),
                "width": str(w),
                "height": str(h),
                "as": "geometry",
            },
        )
        layers[layer].append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="1.2"/>'
        )
        if lines:
            rows = []
            for line in lines:
                formula, fw, fh = None, 0, font
                if line.startswith("$") and line.endswith("$"):
                    from matplotlib import rc_context
                    from matplotlib.font_manager import FontProperties
                    from matplotlib.mathtext import math_to_image

                    buffer = BytesIO()
                    with rc_context(
                        {
                            "mathtext.fontset": "custom",
                            "mathtext.rm": MATH_FAMILY,
                            "mathtext.it": f"{MATH_FAMILY}:italic",
                            "mathtext.bf": f"{MATH_FAMILY}:bold",
                            "mathtext.bfit": f"{MATH_FAMILY}:bold:italic",
                            "mathtext.cal": "STIXGeneral:italic",
                            "mathtext.fallback": "stix",
                            "svg.fonttype": "path",
                        }
                    ):
                        math_to_image(
                            line,
                            buffer,
                            prop=FontProperties(
                                family=MATH_FAMILY, size=math_font or font
                            ),
                            format="svg",
                            color=INK,
                        )
                    formula = ET.fromstring(buffer.getvalue())
                    _, _, fw, fh = map(float, formula.get("viewBox").split())
                rows.append((line, formula, fw, fh))
            row_gap = 5
            content_height = sum(row[3] for row in rows) + row_gap * (len(rows) - 1)
            cursor_y = y + (h - content_height) / 2
            for i, (line, formula, fw, fh) in enumerate(rows):
                center_y = cursor_y + fh / 2
                cursor_y += fh + row_gap
                if formula is not None:
                    formula.set("x", str(x + (w - fw) / 2))
                    formula.set("y", str(center_y - fh / 2))
                    formula.set("width", str(fw))
                    formula.set("height", str(fh))
                    # Namespace glyph IDs: different equations can reuse the same font glyphs.
                    ids = {
                        item.get("id"): f"{name}-{i}-{item.get('id')}"
                        for item in formula.iter()
                        if item.get("id")
                    }
                    for item in formula.iter():
                        if item.get("id"):
                            item.set("id", ids[item.get("id")])
                        for attr, value in list(item.attrib.items()):
                            if value.startswith("#") and value[1:] in ids:
                                item.set(attr, "#" + ids[value[1:]])
                            for old, new in ids.items():
                                value = value.replace(f"url(#{old})", f"url(#{new})")
                            if "url(#" in value:
                                item.set(attr, value)
                    for item in formula.findall(".//{http://www.w3.org/2000/svg}path"):
                        if item.get("style") == "fill: #ffffff":
                            item.set("style", "fill: none")
                    layers[layer].append(ET.tostring(formula, encoding="unicode"))
                    continue
                yy = center_y + font * 0.34
                svg_label = escape(line).replace(
                    "_idx", '<tspan baseline-shift="sub" font-size="12">idx</tspan>'
                )
                layers[layer].append(
                    f'<text x="{x + w / 2}" y="{yy}" text-anchor="middle" font-size="{font}" font-weight="{"bold" if bold and i == 0 else "normal"}">{svg_label}</text>'
                )

    def label(name, x, y, w, h, lines, font=18, bold=False, color=INK):
        node(
            name,
            x,
            y,
            w,
            h,
            lines,
            fill="none",
            stroke="none",
            font=font,
            bold=bold,
            radius=0,
            layer="labels",
        )
        cell = root[-1]
        cell.set(
            "style",
            cell.get("style", "")
            + f"strokeColor=none;fillColor=none;fontColor={color};",
        )
        if color != INK:
            layers["labels"][-1] = layers["labels"][-1].replace(
                "<text ", f'<text fill="{color}" '
            )

    def edge(points, source=None, target=None, *, dashed=False, color=EDGE, arrow=True):
        nonlocal serial
        serial += 1
        # Keep arrow tips and line starts clear of card borders. Explicit routes
        # prevent draw.io's automatic orthogonal router from adding tiny elbows.
        anchors = list(points)
        points = [tuple(map(float, p)) for p in points]
        from math import hypot
        def shift(a, b, distance):
            length = hypot(b[0]-a[0], b[1]-a[1])
            return (a[0]+(b[0]-a[0])*distance/length,
                    a[1]+(b[1]-a[1])*distance/length)
        if source: points[0] = shift(points[0], points[1], 4)
        if target: points[-1] = shift(points[-1], points[-2], 7 if arrow else 4)
        style = (
            f"edgeStyle=none;rounded=1;arcSize=14;html=1;"
            f"strokeColor={color};strokeWidth=2.4;endArrow={'open' if arrow else 'none'};endSize=8;"
            f"endFill=0;dashed={int(dashed)};dashPattern=6 5;"
        )
        attrs = {"id": f"edge-{serial}", "edge": "1", "parent": "1"}
        for key, node_id, point in (
            ("source", source, points[0]),
            ("target", target, points[-1]),
        ):
            if node_id:
                attrs[key] = node_id
                x, y, w, h = positions[node_id]
                axis = "exit" if key == "source" else "entry"
                original = anchors[0] if key == "source" else anchors[-1]
                style += f"{axis}X={(original[0] - x) / w};{axis}Y={(original[1] - y) / h};{axis}Dx={point[0]-original[0]};{axis}Dy={point[1]-original[1]};{axis}Perimeter=0;"
        attrs["style"] = style
        cell = ET.SubElement(root, "mxCell", attrs)
        geom = ET.SubElement(cell, "mxGeometry", {"relative": "1", "as": "geometry"})
        for which, point in (("sourcePoint", points[0]), ("targetPoint", points[-1])):
            ET.SubElement(
                geom, "mxPoint", {"x": str(point[0]), "y": str(point[1]), "as": which}
            )
        if len(points) > 2:
            waypoints = ET.SubElement(geom, "Array", {"as": "points"})
            for x, y in points[1:-1]:
                ET.SubElement(waypoints, "mxPoint", {"x": str(x), "y": str(y)})
        d = f"M {points[0][0]} {points[0][1]}"
        for i in range(1,len(points)-1):
            a,b,c = points[i-1],points[i],points[i+1]
            r=min(12,hypot(b[0]-a[0],b[1]-a[1])/2,hypot(c[0]-b[0],c[1]-b[1])/2)
            before,after=shift(b,a,r),shift(b,c,r)
            d+=f" L {before[0]} {before[1]} Q {b[0]} {b[1]} {after[0]} {after[1]}"
        d+=f" L {points[-1][0]} {points[-1][1]}"
        marker = 'route-arrow' if color == SELECTED else 'arrow'
        layers["edges"].append(
            f'<path d="{d}" fill="none" stroke="{color}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" '
            + ('stroke-dasharray="7 6" ' if dashed else "")
            + (f'marker-end="url(#{marker})"' if arrow else "")
            + "/>"
        )


    # Compact layout reflecting the user's merged Sparse Attention card.
    node("attention-frame", 35, 175, 905, 575, fill=PALE, radius=28, layer="frames")
    label("title", 25, 8, 1880, 42, ["Maxwell Block Sparse Attention"], 30, True)
    label("attention-output", 575, 53, 250, 31, ["Attention Output"], 23)
    label("hidden-states", 345, 777, 270, 31, ["Hidden States"], 23)
    node("output-projection", 590, 105, 220, 54, ["Output Projection"], font=22)
    node("state-merge", 540, 195, 320, 80,
         ["Online-Softmax Merge", r"$O=\frac{e^{\ell_f}O_f+e^{\ell_r}O_r}{e^{\ell_f}+e^{\ell_r}}$"],
         fill=IMPORTANT, important=True, font=22, math_font=17)
    node("block-max", 70, 315, 270, 68,
         ["Block Max Pooling", r"$s_{q,b}^{(g)}=\max_{j\in b} S_{q,j}^{(g)}$"],
         fill=IMPORTANT, important=True, font=22, math_font=17)
    node("fixed-attention", 690, 300, 220, 100,
         ["Fixed Attention", "Prefix-8 + SWA-8"],
         fill=FIXED_FILL, stroke=FIXED_BORDER, font=22)
    node("dynamic-attention", 395, 300, 260, 100,
         ["Sparse Attention", "Remote Top-16",
          r"$\mathcal{R}_{q}^{(g)}=\mathrm{TopK}_{16}(s_{q,b}^{(g)}\mid b\in\mathcal{E}_q)$"],
         fill=SPARSE_FILL, important=True, font=22, math_font=17)
    node("index-score", 70, 405, 270, 68,
         ["Causal Index Score", r"$S^{(g)}=\frac{Q_{\mathrm{idx}}^{(g)}K_{\mathrm{idx}}^{\mathsf{T}}}{\sqrt{128}}$"],
         fill=IMPORTANT, important=True, font=22, math_font=17)
    node("index-k", 100, 513, 90, 50, [r"$K_{\mathrm{idx}}$", "Shared K"], font=14, math_font=22)
    for i in (3, 2, 1):
        node(f"index-q-back-{i}", 225 + 6*i, 513 - 6*i, 90, 50)
    node("index-q", 225, 513, 90, 50, [r"$Q_{\mathrm{idx}}^{(g)}$", "4 groups"], font=14, math_font=22)
    for name, x, letter, stack, heads in (
        ("main-v", 445, "V", 2, "4 heads"),
        ("main-k", 615, "K", 2, "4 heads"),
        ("main-q", 795, "Q", 4, "32 heads"),
    ):
        for i in reversed(range(1, stack)):
            node(f"{name}-back-{i}", x + 6*i, 510 - 6*i, 90, 50, fill=MAIN)
        node(name, x, 510, 90, 50, [f"${letter}$", heads], fill=MAIN, font=14, math_font=24)
    node("index-norm-rope", 100, 597, 210, 54, ["Norm & RoPE"], fill="#F6F1F8")
    node("main-norm-rope", 605, 597, 300, 54, ["Q/K Norm & RoPE"], fill="#F6F1F8")
    node("index-projection", 70, 677, 270, 58, ["Indexer Projection"], font=22)
    node("main-projection", 395, 677, 515, 58,
         ["Shared Q/K/V Projection", "Head dimension 128"], fill="#FFFBF4")
    label("v-bypass", 400, 602, 90, 27, ["V bypass"], 16, color="#7C838C")
    label("index-label", 76, 235, 258, 32, ["Indexer"], 21, True)
    label("remote-eligibility", 390, 409, 270, 22,
          ["Exclude Prefix / SWA / Future"], 15, color="#7C838C")

    edge([(480, 777), (480, 763)], source="hidden-states", arrow=False)
    edge([(480, 763), (205, 763), (205, 735)], target="index-projection")
    edge([(480, 763), (653, 763), (653, 735)], target="main-projection")
    for x, tensor in ((145, "index-k"), (270, "index-q")):
        edge([(x, 677), (x, 651)], "index-projection", "index-norm-rope")
        edge([(x, 597), (x, 563)], "index-norm-rope", tensor)
        edge([(x, 513), (x, 473)], tensor, "index-score")
    edge([(205, 405), (205, 383)], "index-score", "block-max")
    edge([(340, 349), (395, 349)], "block-max", "dynamic-attention", color=SELECTED)
    edge([(755, 677), (755, 651)], "main-projection", "main-norm-rope")
    edge([(660, 597), (660, 560)], "main-norm-rope", "main-k")
    edge([(840, 597), (840, 560)], "main-norm-rope", "main-q")
    edge([(490, 677), (490, 560)], "main-projection", "main-v")
    for x, tensor in ((490,"main-v"), (660,"main-k"), (840,"main-q")):
        edge([(x,510),(x,462)], source=tensor, arrow=False)
    edge([(490,462),(840,462)], arrow=False)
    edge([(800,462),(800,400)], target="fixed-attention")
    edge([(640,462),(640,400)], target="dynamic-attention")
    edge([(570,300),(570,275)], "dynamic-attention", "state-merge")
    edge([(800,300),(800,275)], "fixed-attention", "state-merge")
    edge([(700,195),(700,159)], "state-merge", "output-projection")
    edge([(700,105),(700,84)], "output-projection", "attention-output")

    # A coarse sampled grid makes blocks legible without changing the 8/16/8 contract.
    node(
        "mask-title",
        1245,
        220,
        400,
        58,
        ["Block Attention Mask"],
        fill=IMPORTANT,
        important=True,
        font=26,
    )
    edge(
        [(860, 235), (955, 235), (955, 249), (1245, 249)],
        "state-merge",
        "mask-title",
        dashed=True,
    )
    # Show one Prefix column and one SWA cell per row in the sampled schematic.
    sampled_blocks = (0, 12, 28, 44, 60, 76, 92, 108, 124, 140, 156, 172)
    for group, x in ((0, 975), (1, 1455)):
        node(
            f"mask-frame-{group}",
            x,
            310,
            460,
            364.5,
            fill=PALE,
            radius=20,
            layer="frames",
        )
        node(
            f"group-title-{group}",
            x + 120,
            287.5,
            220,
            45,
            [f"Query Group {group + 1}"],
            font=23,
        )
        start_x, start_y, block_width, block_height = x + 26, 404.5, 34, 18
        for row, query_block in enumerate(sampled_blocks):
            prefix = set(range(min(8, query_block + 1)))
            swa = set(range(max(8, query_block - 7), query_block + 1))
            fixed = prefix | swa
            remote = [block for block in range(query_block + 1) if block not in fixed]
            # Construct an illustrative legal Top-16 route before sampling.
            # Rotating pairs give separated remote patches rather than a solid
            # early-column slab. These are example routes, not measured scores.
            visible = [(col, block) for col, block in enumerate(sampled_blocks[:row])
                       if block in remote]
            preferred = [block for col, block in visible
                         if (col + (row//2)*2 + group*2) % 6 in (1,2)]
            if visible and not preferred:
                preferred = [visible[-1][1]]
            unsampled = [block for block in remote
                         if block not in sampled_blocks and block not in preferred]
            remaining = [block for block in remote
                         if block not in preferred and block not in unsampled]
            selected_remote = set((preferred + unsampled + remaining)[:16])
            assert len(selected_remote) == min(16, len(remote))
            assert not selected_remote & fixed
            for col, block in enumerate(sampled_blocks[: row + 1]):
                fill = (
                    PREFIX
                    if block in prefix
                    else SWA
                    if block in swa
                    else REMOTE
                    if block in selected_remote
                    else "#ffffff"
                )
                node(
                    f"mask-{group}-{row}-{col}",
                    start_x + col * block_width,
                    start_y + row * block_height,
                    block_width,
                    block_height,
                    fill=fill,
                    stroke="#E1E4E8",
                    radius=0,
                )
        label(f"mask-axis-{group}", x + 30, 638.5, 400, 26, ["Query ↓    KV Block →"], 18, color="#7C838C")
        for kind, caption, color, dx, dy in (
            ("prefix", "Prefix-8", PREFIX, 32, 351),
            ("swa", "SWA-8", SWA, 250, 351),
            ("remote", "Remote Top-16", REMOTE, 32, 378),
            ("unselected", "Non-selected", "#ffffff", 250, 378),
        ):
            node(f"legend-{kind}-{group}", x + dx, dy, 24, 14, fill=color, radius=0)
            label(
                f"legend-label-{kind}-{group}",
                x + dx + 31,
                dy - 7,
                150,
                28,
                [caption],
                16,
            )
    label(
        "mask-note",
        975,
        705,
        940,
        40,
        ["128 tokens per KV block · two of four query groups shown (schematic)"],
        17,
        color="#7C838C",
    )

    # Native parent/child groups keep each editable mask together when moved.
    for group in (0, 1):
        frame = next(cell for cell in root if cell.get("id") == f"mask-frame-{group}")
        frame.set(
            "style",
            frame.get("style", "") + "container=1;collapsible=0;recursiveResize=1;",
        )
        fx, fy, _, _ = positions[f"mask-frame-{group}"]
        for cell in root:
            name = cell.get("id", "")
            member = (
                name.startswith(f"mask-{group}-")
                or name
                in (
                    f"group-title-{group}",
                    f"mask-axis-{group}",
                )
                or (name.startswith("legend-") and name.endswith(f"-{group}"))
            )
            if member:
                cell.set("parent", f"mask-frame-{group}")
                geom = cell.find("mxGeometry")
                geom.set("x", str(float(geom.get("x")) - fx))
                geom.set("y", str(float(geom.get("y")) - fy))

    # Match preview layering: connectors pass behind cards, never across labels.
    def native_layer(cell):
        name = cell.get("id", "")
        if name in ("0", "1"): return -1
        if name == "attention-frame" or name.startswith("mask-frame-"): return 0
        if cell.get("edge") == "1": return 1
        if "fillColor=none;strokeColor=none;" in cell.get("style", ""): return 3
        return 2
    root[:] = sorted(root, key=native_layer)
    ET.indent(mxfile, space="  ")
    ET.ElementTree(mxfile).write(
        OUTPUT.with_suffix(".drawio"), encoding="utf-8", xml_declaration=True
    )
    svg = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}">',
        f'<defs><marker id="arrow" markerUnits="userSpaceOnUse" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M1 1 L8 4.5 L1 8" fill="none" stroke="{EDGE}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"/></marker><marker id="route-arrow" markerUnits="userSpaceOnUse" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto"><path d="M1 1 L8 4.5 L1 8" fill="none" stroke="{SELECTED}" stroke-width="2.0" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>',
        f'<rect width="{WIDTH}" height="{HEIGHT}" fill="white"/>',
        f'<g font-family="\'{FONT_FAMILY}\',Times,serif" fill="{INK}">',
    ]
    for layer in layers.values():
        svg.extend(layer)
    svg.extend(["</g>", "</svg>"])
    svg_text = "\n".join(line.rstrip() for line in "\n".join(svg).splitlines())
    OUTPUT.with_suffix(".svg").write_text(svg_text, encoding="utf-8")
    if png:
        import resvg_py

        OUTPUT.with_suffix(".png").write_bytes(
            resvg_py.svg_to_bytes(svg_string=svg_text, width=3000)
        )
    print(f"Saved editable Attention diagram: {OUTPUT.with_suffix('.drawio')}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--png", action="store_true")
    generate(parser.parse_args().png)

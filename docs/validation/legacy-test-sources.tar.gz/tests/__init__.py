"""Semantic and backend alignment tests."""

"""Ensure the package remains usable without loading accelerator runtimes."""

import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch


class ImportBoundaryTest(unittest.TestCase):
    def test_partial_precision_switch_and_explicit_override(self):
        import torch
        from mbsa.cutedsl_backend import _resolve_partial_dtype

        for mode, expected in (("0", torch.bfloat16), ("1", torch.float8_e4m3fn)):
            with self.subTest(mode=mode), patch.dict(os.environ, {"MBSA_FP8_PARTIAL_OUT": mode}):
                self.assertEqual(_resolve_partial_dtype(None), expected)
                self.assertEqual(_resolve_partial_dtype(torch.bfloat16), torch.bfloat16)
        with patch.dict(os.environ, {"MBSA_FP8_PARTIAL_OUT": "invalid"}):
            with self.assertRaisesRegex(ValueError, "MBSA_FP8_PARTIAL_OUT"):
                _resolve_partial_dtype(None)
        with self.assertRaisesRegex(ValueError, "partial_dtype"):
            _resolve_partial_dtype(torch.float32)

    def test_public_import_is_lazy(self):
        env = os.environ.copy()
        env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "python")
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                "import sys; import mbsa; "
                "assert mbsa.__all__ == ['reference_pipeline', 'triton_pipeline', 'prepare_cutedsl_pipeline']; "
                "assert not {'torch','triton','cutlass','fmha_sm100'}.intersection(sys.modules)",
            ],
            env=env,
            text=True,
            capture_output=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_cutedsl_rejects_cpu_before_loading_runtime(self):
        env = os.environ.copy()
        env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "python")
        script = r"""
import sys, torch
from mbsa import prepare_cutedsl_pipeline
q = torch.zeros((1, 32, 128))
try:
    prepare_cutedsl_pipeline(q, q, q, q, q)
except ValueError as error:
    assert 'CUDA' in str(error), str(error)
else:
    raise AssertionError('CPU input must be rejected')
assert 'fmha_sm100' not in sys.modules
assert 'cutlass' not in sys.modules
"""
        result = subprocess.run(
            [sys.executable, "-c", script], env=env, text=True, capture_output=True
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_bundled_runtime_does_not_take_over_global_modules(self):
        env = os.environ.copy()
        env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "python")
        script = r"""
import importlib, sys, types
from mbsa.cutedsl_backend import _load_runtime
globals_before = {}
for name in ('src', 'interface', 'sparse_index_utils', 'fmha_sm100'):
    globals_before[name] = sys.modules[name] = types.ModuleType(name)
base = 'mbsa._vendor.msa.python.fmha_sm100'
sentinel = object()
for suffix, names in (
    ('.cute.interface', ('SparseForwardPhase', 'sparse_atten_func')),
    ('.cute.sparse_index_utils', ('build_k2q_csr',)),
    ('.cute.src.sm100.prepare_k2q_csr', ('SparseK2qCsrBuilderSm100', 'allocate_k2q_csr_scratch')),
):
    module = types.ModuleType(base + suffix)
    for name in names:
        setattr(module, name, sentinel)
    sys.modules[module.__name__] = module
path_before = sys.path[:]
_load_runtime()
owned = importlib.import_module(base)
assert owned.sparse_atten_func is sentinel
assert sys.path == path_before
assert all(sys.modules[name] is value for name, value in globals_before.items())
"""
        result = subprocess.run(
            [sys.executable, "-c", script], env=env, text=True, capture_output=True
        )
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__":
    unittest.main()

"""Align retained accelerator paths with the upstream Python contract."""

import sys
import importlib.util
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
import torch
from mbsa import reference_pipeline


CUTEDSL_ARCHS = ((9, 0), (10, 3))


@unittest.skipUnless(torch.cuda.is_available(), "CUDA is required")
class BackendAlignment(unittest.TestCase):
    def inputs(self, qn, kn):
        torch.manual_seed(17)

        def rand(shape):
            return torch.randn(shape, device="cuda", dtype=torch.bfloat16)

        return (
            rand((qn, 4, 128)),
            rand((kn, 1, 128)),
            rand((qn, 32, 128)),
            rand((kn, 4, 128)),
            rand((kn, 4, 128)),
        )

    def compare(self, actual, expected):
        out, lse, route = actual
        eo, el, er = expected
        # Python topk and the kernels may order equal scores differently.
        torch.testing.assert_close(
            route.sort(-1).values, er.sort(-1).values, rtol=0, atol=0
        )
        torch.testing.assert_close(out, eo, rtol=0.03, atol=0.03)
        torch.testing.assert_close(lse, el, rtol=0.002, atol=0.01)

    def test_triton(self):
        if importlib.util.find_spec("triton") is None:
            self.skipTest("Triton is required")
        from mbsa import triton_pipeline

        for qn, kn in ((128, 4096), (17, 4113), (128, 128)):
            with self.subTest(q=qn, kv=kn):
                operands = self.inputs(qn, kn)
                self.compare(triton_pipeline(*operands), reference_pipeline(*operands))

    def test_triton_rejects_unaligned_offset(self):
        if importlib.util.find_spec("triton") is None:
            self.skipTest("Triton is required")
        from mbsa import triton_pipeline

        with self.assertRaisesRegex(ValueError, "block-aligned"):
            triton_pipeline(*self.inputs(16, 4096))

    def test_cutedsl(self):
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa import prepare_cutedsl_pipeline

        for qn, kn in ((16, 4096), (16, 4113), (128, 128)):
            with self.subTest(q=qn, kv=kn):
                operands = self.inputs(qn, kn)
                self.compare(
                    prepare_cutedsl_pipeline(*operands).run(),
                    reference_pipeline(*operands),
                )

    def test_cutedsl_fp8_partial_storage_matches_reference(self):
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa import prepare_cutedsl_pipeline

        for qn, kn in ((128, 8192), (17, 4113)):
            with self.subTest(q=qn, kv=kn):
                operands = self.inputs(qn, kn)
                pipeline = prepare_cutedsl_pipeline(
                    *operands, partial_dtype=torch.float8_e4m3fn
                )
                self.assertEqual(
                    pipeline.plan.attention.dynamic_workspace[0].dtype,
                    torch.float8_e4m3fn,
                )
                self.compare(pipeline.run(), reference_pipeline(*operands))

    def test_cutedsl_packed_permuted_index_pages(self):
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa import prepare_cutedsl_pipeline

        lengths = ((17, 4113), (23, 2195))
        operands = [self.inputs(qn, kn) for qn, kn in lengths]
        iq, q, k, v = (
            torch.cat([request[i] for request in operands]) for i in (0, 2, 3, 4)
        )
        pages = []
        for request in operands:
            ik = request[1]
            padded = torch.zeros(
                ((ik.shape[0] + 127) // 128 * 128, 1, 128),
                device="cuda",
                dtype=torch.bfloat16,
            )
            padded[: ik.shape[0]].copy_(ik)
            pages.append(padded.view(-1, 1, 128, 128))
        logical_ik = torch.cat(pages)
        permutation = torch.arange(logical_ik.shape[0] - 1, -1, -1, device="cuda")
        physical_ik = torch.empty_like(logical_ik)
        physical_ik.index_copy_(0, permutation, logical_ik)
        cu_q = torch.tensor([0, 17, 40], dtype=torch.int32, device="cuda")
        cu_k = torch.tensor([0, 4113, 6308], dtype=torch.int32, device="cuda")
        actual = prepare_cutedsl_pipeline(
            iq,
            physical_ik,
            q,
            k,
            v,
            cu_seqlens_q=cu_q,
            cu_seqlens_k=cu_k,
            index_page_indices=permutation.to(torch.int32),
        ).run()
        start = 0
        for request, (qn, _) in zip(operands, lengths):
            qs = slice(start, start + qn)
            self.compare(
                (actual[0][qs], actual[1][qs], actual[2][:, qs]),
                reference_pipeline(*request),
            )
            start += qn

    def test_cutedsl_permuted_kv_pages_with_tail(self):
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa import prepare_cutedsl_pipeline

        operands = self.inputs(17, 4113)
        iq, ik, q, k, v = operands
        blocks = (k.shape[0] + 127) // 128
        permutation = torch.arange(blocks - 1, -1, -1, device="cuda")

        def paged(tensor):
            padded = torch.zeros(
                (blocks * 128, 4, 128), dtype=tensor.dtype, device=tensor.device
            )
            padded[: tensor.shape[0]].copy_(tensor)
            logical = padded.view(blocks, 128, 4, 128).permute(0, 2, 1, 3).contiguous()
            physical = torch.empty_like(logical)
            physical.index_copy_(0, permutation, logical)
            return physical

        actual = prepare_cutedsl_pipeline(
            iq,
            ik,
            q,
            paged(k),
            paged(v),
            page_table=permutation.to(torch.int32).unsqueeze(0),
            logical_k_tokens=k.shape[0],
        ).run()
        self.compare(actual, reference_pipeline(*operands))

    def test_cutedsl_vllm_interleaved_cache_and_single_query_chunk(self):
        """Use the actual split/permuted cache strides, including a KV tail."""
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa import prepare_cutedsl_pipeline

        for qn, kn in (
            (1, 4113),
            (17, 4113),
            (1, 16384),
            (17, 16384),
            (16, 16384),
            (16, 16385),
        ):
            operands = self.inputs(qn, kn)
            iq, ik, q, k, v = operands
            blocks = (k.shape[0] + 127) // 128
            pool = torch.zeros((blocks, 128, 4, 2, 128), device="cuda", dtype=q.dtype)
            permutation = torch.arange(blocks - 1, -1, -1, device="cuda")
            for half, tensor in enumerate((k, v)):
                padded = torch.zeros(
                    (blocks * 128, 4, 128), device="cuda", dtype=q.dtype
                )
                padded[: tensor.shape[0]].copy_(tensor)
                pool[..., half, :].index_copy_(
                    0, permutation, padded.view(blocks, 128, 4, 128)
                )
            kp, vp = (pool[..., half, :].permute(0, 2, 1, 3) for half in (0, 1))
            self.assertEqual(kp.permute(0, 2, 1, 3).stride(), (131072, 1024, 256, 1))
            self.assertEqual(vp.data_ptr() - kp.data_ptr(), 128 * q.element_size())
            actual = prepare_cutedsl_pipeline(
                iq,
                ik,
                q,
                kp,
                vp,
                page_table=permutation.to(torch.int32).unsqueeze(0),
                logical_k_tokens=k.shape[0],
            ).run()
            self.compare(actual, reference_pipeline(*operands))

    def test_cutedsl_rebind_refreshes_index_pages_and_fused_output(self):
        """A reused plan must read the new layer and identity-to-permuted map."""
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa import prepare_cutedsl_pipeline

        first = self.inputs(17, 8192)
        second = tuple(tensor.roll(1, 0).add(0.125) for tensor in first)
        blocks = 64

        def physical(operands, permute):
            iq, ik, q, k, v = operands
            pages = torch.arange(blocks, dtype=torch.int32, device="cuda")
            if permute:
                pages = pages.flip(0)
            pool = torch.empty((blocks, 128, 4, 2, 128), device="cuda", dtype=q.dtype)
            for half, tensor in enumerate((k, v)):
                pool[..., half, :].index_copy_(
                    0, pages.long(), tensor.view(blocks, 128, 4, 128)
                )
            ip = torch.empty((blocks, 1, 128, 128), device="cuda", dtype=q.dtype)
            ip.index_copy_(0, pages.long(), ik.view(blocks, 1, 128, 128))
            return (
                iq,
                ip,
                q,
                pool[..., 0, :].permute(0, 2, 1, 3),
                pool[..., 1, :].permute(0, 2, 1, 3),
                pages,
            )

        iq, ik, q, k, v, pages = physical(first, False)
        pipeline = prepare_cutedsl_pipeline(
            iq,
            ik,
            q,
            k,
            v,
            index_page_indices=pages,
            page_table=pages.unsqueeze(0),
            logical_k_tokens=8192,
        )
        self.compare(pipeline.run(), reference_pipeline(*first))
        iq, ik, q, k, v, pages = physical(second, True)
        out = torch.empty_like(q)
        pipeline.rebind(
            iq,
            ik,
            q,
            k,
            v,
            index_page_indices=pages,
            page_table=pages.unsqueeze(0),
            out=out,
        )
        actual = pipeline.run()
        self.assertEqual(actual[0].data_ptr(), out.data_ptr())
        self.compare(actual, reference_pipeline(*second))

    def test_vllm_adapter_reuses_packed_plan_with_new_layer_and_page_maps(self):
        """Packed routing and output ownership survive a real layer rebind."""
        self._check_vllm_adapter_rebind(use_graphs=False)

    def test_vllm_graph_adapter_replays_updated_queries_cache_and_page_maps(self):
        """Captured kernels must consume live values through stable staging."""
        self._check_vllm_adapter_rebind(use_graphs=True)

    def _check_vllm_adapter_rebind(self, use_graphs):
        if torch.cuda.get_device_capability() not in CUTEDSL_ARCHS:
            self.skipTest("qualified CuTe DSL runtime requires SM90 or SM103")
        from mbsa.vllm import PagedPrefill

        lengths = ((1, 130), (1, 4098), (17, 8193))
        counts = [(kn + 127) // 128 for _, kn in lengths]
        adapter = PagedPrefill(max_cached_plans=1, use_graphs=use_graphs)
        rounds = 3 if use_graphs else 2
        for iteration in range(rounds):
            operands = [
                tuple(t.add(iteration * 0.125) for t in self.inputs(qn, kn))
                for qn, kn in lengths
            ]
            iq, q = (torch.cat([row[i] for row in operands]) for i in (0, 2))
            if iteration != 2:
                pool = torch.zeros(
                    (sum(counts), 128, 4, 2, 128), device="cuda", dtype=q.dtype
                )
                ik = torch.zeros(
                    (sum(counts), 1, 128, 128), device="cuda", dtype=q.dtype
                )
            pages = torch.arange(sum(counts), device="cuda", dtype=torch.int32)
            if iteration % 2:
                pages = pages.flip(0)
            table = torch.zeros(
                (len(lengths), max(counts)), device="cuda", dtype=torch.int32
            )
            page_start = 0
            for slot, (row, count) in enumerate(zip(operands, counts)):
                ids = pages[page_start : page_start + count]
                table[slot, :count].copy_(ids)
                for half, tensor in enumerate(row[3:5]):
                    padded = torch.zeros(
                        (count * 128, 4, 128), device="cuda", dtype=q.dtype
                    )
                    padded[: tensor.shape[0]].copy_(tensor)
                    pool[..., half, :].index_copy_(
                        0, ids.long(), padded.view(count, 128, 4, 128)
                    )
                padded = torch.zeros(
                    (count * 128, 1, 128), device="cuda", dtype=q.dtype
                )
                padded[: row[1].shape[0]].copy_(row[1])
                ik.index_copy_(0, ids.long(), padded.view(count, 1, 128, 128))
                page_start += count
            out = torch.empty_like(q)
            actual = adapter(
                q,
                pool[..., 0, :],
                pool[..., 1, :],
                index_q=iq,
                index_k_cache=ik[:, 0],
                index_page_indices=pages,
                page_table=table,
                request_lens=lengths,
                out=out,
                partial_dtype=torch.bfloat16,
            )
            self.assertEqual(actual.data_ptr(), out.data_ptr())
            pipeline = next(iter(adapter.plans.values()))
            lse = pipeline.plan.attention.out_lse
            route = pipeline.plan.attention.tile_plan.dynamic_route
            start = 0
            for row, (qn, _) in zip(operands, lengths):
                qs = slice(start, start + qn)
                self.compare(
                    (actual[qs], lse[qs], route[:, qs]), reference_pipeline(*row)
                )
                start += qn
        self.assertEqual((adapter.hits, adapter.misses), (rounds - 1, 1))
        if use_graphs:
            self.assertEqual(len(pipeline._vllm_graphs), 2)


if __name__ == "__main__":
    unittest.main()

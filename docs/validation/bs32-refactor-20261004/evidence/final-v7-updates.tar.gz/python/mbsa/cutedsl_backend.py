"""Public preparation API for the BF16 CuTe DSL performance path."""

from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
import os

import torch


def _resolve_partial_dtype(partial_dtype: torch.dtype | None) -> torch.dtype:
    if partial_dtype is None:
        mode = os.environ.get("MBSA_FP8_PARTIAL_OUT", "0")
        if mode not in ("0", "1"):
            raise ValueError("MBSA_FP8_PARTIAL_OUT must be 0 or 1")
        partial_dtype = torch.float8_e4m3fn if mode == "1" else torch.bfloat16
    if partial_dtype not in (torch.bfloat16, torch.float8_e4m3fn):
        raise ValueError("partial_dtype must be BF16 or FP8 E4M3FN")
    return partial_dtype


def _load_runtime() -> None:
    # A source install includes attributed runtime snapshots. Import them only
    # when the performance backend is requested; CPU reference imports stay cheap.
    import_module("._vendor.msa.python.fmha_sm100.sparse", __package__)


@dataclass
class CutedslPipeline:
    """Reusable plan; run returns output, natural-log LSE, dynamic block IDs."""

    plan: object

    def run(self) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        output, lse = self.plan.run()
        return output, lse, self.plan.attention.tile_plan.dynamic_route

    def rebind(
        self, index_q, index_k, q, k, v, *, index_page_indices, page_table, out
    ) -> None:
        """Rebind paged inputs with identical shapes, strides and lengths.

        Logical request lengths belong to the prepared plan. Page mappings
        may change; the caller must supply valid physical page IDs. This
        operation refreshes every cloned routing map without a host sync.
        Rebinding a plan owning a captured mega graph is forbidden because
        its graph embeds the original pointers.
        """
        p = self.plan
        if hasattr(p, "rebind"):
            p.rebind(
                index_q,
                index_k,
                q,
                k,
                v,
                index_page_indices=index_page_indices,
                page_table=page_table,
                out=out,
            )
            return
        a = p.attention
        if p.mega_graph_captured:
            raise RuntimeError("cannot rebind a captured mega graph")
        if k.ndim != 4:
            raise ValueError("rebind requires physical paged K/V")
        pairs = (
            ("index_q", index_q, p.index_q),
            ("index_k", index_k, p.index_k),
            ("q", q, a.q),
            ("k", k, a.k),
            ("v", v, a.v),
            ("index_page_indices", index_page_indices, p.index_page_indices),
            ("page_table", page_table, a.tile_plan.page_table),
            ("out", out, a.out),
        )
        for name, new, old in pairs:
            if (new.shape, new.stride(), new.dtype, new.device) != (
                old.shape,
                old.stride(),
                old.dtype,
                old.device,
            ):
                raise ValueError(
                    f"{name} must retain prepared shape/stride/dtype/device"
                )
        counts = tuple(
            (ke - kb + 127) // 128 for _, _, kb, ke in a.fixed_request_ranges
        )
        if index_page_indices.ndim == 2:
            rows = tuple(index_page_indices[i, :n] for i, n in enumerate(counts))
        elif index_page_indices.numel() == sum(counts):
            rows = index_page_indices.split(counts)
        else:
            padded = index_page_indices.view(a.batch, -1)
            rows = tuple(padded[i, :n] for i, n in enumerate(counts))
        if p.cutedsl_index_pages is not None:
            p.cutedsl_index_pages = rows[0]
            p.cutedsl_use_page_table = True
        if p.cutedsl_packed_pages is not None:
            if index_page_indices.ndim == 1 and index_page_indices.numel() == sum(
                counts
            ):
                p.cutedsl_packed_pages = index_page_indices
            else:
                offset = 0
                for row in rows:
                    p.cutedsl_packed_pages[offset : offset + row.numel()].copy_(row)
                    offset += row.numel()
        p.index_q, p.index_k, p.index_page_indices = (
            index_q,
            index_k,
            index_page_indices,
        )
        if p.cutedsl_index_k is not None:
            p.cutedsl_index_k = index_k.view(-1, 1, 128)
        a.q, a.k, a.v = q, k, v
        a.tile_plan.page_table = page_table
        if a.fixed_out is a.out:
            a.fixed_out = out
        if a.dynamic_out is a.out:
            a.dynamic_out = out
        a.out = out


def _prepare_sm90(
    index_q,
    index_k,
    q,
    k,
    v,
    *,
    cu_seqlens_q,
    cu_seqlens_k,
    index_page_indices,
    page_table,
    logical_k_tokens,
    overlap_fixed_score,
    partial_dtype,
    out,
) -> CutedslPipeline:
    """H100 path: packed or paged main K/V, paged Index-K, BF16/FP8 partials."""
    if (cu_seqlens_q is None) != (cu_seqlens_k is None):
        raise ValueError("cu_seqlens_q and cu_seqlens_k must be provided together")
    if cu_seqlens_q is None:
        if k.ndim == 4 and logical_k_tokens is None:
            raise ValueError("paged KV requires logical_k_tokens")
        kv_len = logical_k_tokens if logical_k_tokens is not None else k.shape[0]
        q_lens, kv_lens = (q.shape[0],), (kv_len,)
    else:
        if logical_k_tokens is not None:
            raise ValueError("packed lengths are owned by cu_seqlens_k")
        q_prefix = cu_seqlens_q.cpu().tolist()
        k_prefix = cu_seqlens_k.cpu().tolist()
        q_lens = tuple(b - a for a, b in zip(q_prefix, q_prefix[1:]))
        kv_lens = tuple(b - a for a, b in zip(k_prefix, k_prefix[1:]))
    if not q_lens or len(q_lens) != len(kv_lens):
        raise ValueError("Q/KV prefix sums must describe the same non-empty batch")
    if any(
        not 0 < qn <= min(kn, 8192) or kn > 1048576 for qn, kn in zip(q_lens, kv_lens)
    ):
        raise ValueError("each request requires 0 < Q <= 8192 and Q <= KV <= 1M")
    if (k.ndim == 4) != (page_table is not None):
        raise ValueError(
            "page_table is required for, and only valid with, physical KV pages"
        )
    request_blocks = tuple((n + 127) // 128 for n in kv_lens)
    if index_page_indices is None:
        index_page_indices = torch.arange(
            sum(request_blocks), dtype=torch.int32, device=q.device
        )
    if index_k.ndim == 3 and index_k.shape[0] % 128:
        if len(q_lens) != 1:
            raise ValueError("packed Index-K requires physical pages")
        padded = torch.zeros(
            (request_blocks[0] * 128, 1, 128),
            dtype=index_k.dtype,
            device=index_k.device,
        )
        padded[: index_k.shape[0]].copy_(index_k)
        index_k = padded
    from .cute.sm90 import prepare_sm90_pipeline

    plan = prepare_sm90_pipeline(
        index_q,
        index_k,
        q,
        k,
        v,
        q_lens=q_lens,
        kv_lens=kv_lens,
        index_page_indices=index_page_indices,
        page_table=page_table,
        partial_dtype=_resolve_partial_dtype(partial_dtype),
        overlap_fixed_score=overlap_fixed_score,
        out=out,
    )
    return CutedslPipeline(plan)


def prepare_cutedsl_pipeline(
    index_q: torch.Tensor,
    index_k: torch.Tensor,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    *,
    cu_seqlens_q: torch.Tensor | None = None,
    cu_seqlens_k: torch.Tensor | None = None,
    index_page_indices: torch.Tensor | None = None,
    page_table: torch.Tensor | None = None,
    logical_k_tokens: int | None = None,
    overlap_fixed_score: bool | None = None,
    partial_dtype: torch.dtype | None = None,
    out: torch.Tensor | None = None,
) -> CutedslPipeline:
    """Prepare batch-one or packed BF16 prefill on SM103.

    Q/Index-Q are NHD tensors. KV can be NHD or physical PHTD pages.
    Paged Index-K is [pages,1,128,128]. Tables contain request-logical to
    physical page IDs. Packed calls supply CUDA int32 prefix sums for Q/KV.
    All allocations and validation occur here, before repeated ``run`` calls.
    Partial outputs default to BF16. Set ``MBSA_FP8_PARTIAL_OUT=1`` for FP8
    E4M3FN partial storage, or pass ``partial_dtype`` explicitly. Q/K/V and
    final output remain BF16; LSE and the state reduction remain FP32.
    """
    if not q.is_cuda:
        raise ValueError("CuTe DSL requires CUDA tensors on SM90 or SM103")
    capability = torch.cuda.get_device_capability(q.device)
    if capability == (9, 0):
        return _prepare_sm90(
            index_q,
            index_k,
            q,
            k,
            v,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            index_page_indices=index_page_indices,
            page_table=page_table,
            logical_k_tokens=logical_k_tokens,
            overlap_fixed_score=overlap_fixed_score,
            partial_dtype=partial_dtype,
            out=out,
        )
    if capability != (10, 3):
        raise ValueError("the qualified CuTe DSL router requires SM90 or SM103")
    partial_dtype = _resolve_partial_dtype(partial_dtype)
    if (cu_seqlens_q is None) != (cu_seqlens_k is None):
        raise ValueError("cu_seqlens_q and cu_seqlens_k must be provided together")
    if cu_seqlens_q is None:
        if k.ndim == 4 and logical_k_tokens is None:
            raise ValueError("paged KV requires logical_k_tokens")
        kv_len = logical_k_tokens if logical_k_tokens is not None else k.shape[0]
        q_lens, kv_lens = (q.shape[0],), (kv_len,)
    else:
        if logical_k_tokens is not None:
            raise ValueError("packed lengths are owned by cu_seqlens_k")
        q_prefix = cu_seqlens_q.cpu().tolist()
        k_prefix = cu_seqlens_k.cpu().tolist()
        q_lens = tuple(b - a for a, b in zip(q_prefix, q_prefix[1:]))
        kv_lens = tuple(b - a for a, b in zip(k_prefix, k_prefix[1:]))
    if not q_lens or len(q_lens) != len(kv_lens):
        raise ValueError("Q/KV prefix sums must describe the same non-empty batch")
    if any(
        not 0 < qn <= min(kn, 8192) or kn > 1048576 for qn, kn in zip(q_lens, kv_lens)
    ):
        raise ValueError("each request requires 0 < Q <= 8192 and Q <= KV <= 1M")
    _load_runtime()
    from .cute.interface import prepare_pipeline
    from .cute.plan import FwdTilePlan, PrefillPolicy

    request_blocks = tuple((n + 127) // 128 for n in kv_lens)
    if index_page_indices is None:
        index_page_indices = torch.arange(
            sum(request_blocks), dtype=torch.int32, device=q.device
        )
    if index_k.ndim == 3 and index_k.shape[0] % 128:
        if len(q_lens) != 1:
            raise ValueError("packed Index-K requires physical pages")
        padded = torch.zeros(
            (request_blocks[0] * 128, 1, 128),
            dtype=index_k.dtype,
            device=index_k.device,
        )
        padded[: index_k.shape[0]].copy_(index_k)
        index_k = padded.view(-1, 1, 128, 128)
    policy = (
        PrefillPolicy.ALIGNED_PAGED if k.ndim == 4 else PrefillPolicy.ALIGNED_CONTIGUOUS
    )
    if policy is PrefillPolicy.ALIGNED_PAGED and page_table is None:
        raise ValueError("paged KV requires page_table")
    if policy is PrefillPolicy.ALIGNED_CONTIGUOUS and page_table is not None:
        raise ValueError("page_table is only valid for physical KV pages")
    if page_table is None:
        page_table = torch.empty((len(q_lens), 0), dtype=torch.int32, device=q.device)
    offsets = tuple(kn - qn for qn, kn in zip(q_lens, kv_lens))
    tile_plan = FwdTilePlan(
        dynamic_route=torch.full(
            (4, q.shape[0], 16), -1, dtype=torch.int32, device=q.device
        ),
        page_table=page_table,
        valid_kv_tokens=torch.tensor(kv_lens, dtype=torch.int32, device=q.device),
        q_offset_tokens=offsets[0] if len(offsets) == 1 else offsets,
        policy=policy,
    )
    if overlap_fixed_score is None and len(q_lens) == 1:
        overlap_fixed_score = True
    plan = prepare_pipeline(
        index_q=index_q,
        index_k=index_k,
        index_page_indices=index_page_indices,
        candidate_storage=torch.empty(
            (4, 32, q.shape[0]), dtype=torch.float32, device=q.device
        ),
        prefix_lens=torch.tensor(offsets, dtype=torch.int32, device=q.device),
        q=q,
        k=k,
        v=v,
        tile_plan=tile_plan,
        out=torch.empty_like(q) if out is None else out,
        partial_dtype=partial_dtype,
        fuse_fixed_state_in_dynamic_combine=len(q_lens) == 1,
        overlap_fixed_score=overlap_fixed_score,
        cu_seqlens_q=cu_seqlens_q,
        cu_seqlens_k=cu_seqlens_k,
    )
    return CutedslPipeline(plan)

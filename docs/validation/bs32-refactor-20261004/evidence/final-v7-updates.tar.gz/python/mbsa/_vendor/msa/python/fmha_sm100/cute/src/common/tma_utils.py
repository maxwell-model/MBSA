# SPDX-FileCopyrightText: Copyright (c) 2026 MiniMax
# SPDX-License-Identifier: MIT

"""Raw TMA ops and descriptor builders.

`tma_utils.py` is the canonical owner for raw TMA inline-asm helpers and TMA
descriptor construction. Non-TMA store/layout helpers are re-exported from
`copy_utils.py` for backward compatibility.
"""

import ctypes

import cutlass
from cutlass import Int32, Int64
from cutlass.cutlass_dsl import T, dsl_user_op
from cutlass._mlir.dialects import llvm
import cutlass._mlir.dialects.cute as cute_ir
import cutlass._mlir.dialects.cute_nvgpu as cute_nvgpu_ir
from cutlass._mlir.dialects import _cute_nvgpu_ops_gen as cute_nvgpu_gen


# Raw TMA Ops

TMA_CACHE_EVICT_FIRST = 0x12F0000000000000
TMA_CACHE_EVICT_LAST = 0x14F0000000000000


@dsl_user_op
def tma_tile_load(
    smem_ptr,
    smem_byte_offset,
    tma_desc_ptr,
    col_idx,
    row_idx,
    mbar_ptr,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.tensor.2d.shared::cta.global.tile with mbar completion."""
    llvm.inline_asm(
        T.i32(),
        [
            smem_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(smem_byte_offset).ir_value(loc=loc, ip=ip),
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row_idx).ir_value(loc=loc, ip=ip),
            mbar_ptr.toint().ir_value(loc=loc, ip=ip),
        ],
        "{\n"
        ".reg .u32 sa, ma;\n"
        "cvt.u32.u64 sa, $1;\n"
        "add.u32 sa, sa, $2;\n"
        "cvt.u32.u64 ma, $6;\n"
        "cp.async.bulk.tensor.2d.shared::cta.global.tile"
        ".mbarrier::complete_tx::bytes [sa], [$3, {$4, $5}], [ma];\n"
        "mov.u32 $0, 0;\n"
        "}\n",
        "=r,l,r,l,r,r,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def tma_gather4(
    smem_ptr,
    smem_byte_offset,
    tma_desc_ptr,
    col_idx,
    row0,
    row1,
    row2,
    row3,
    mbar_ptr,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.tensor.2d.shared::cta.global.tile::gather4 with mbar."""
    llvm.inline_asm(
        T.i32(),
        [
            smem_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(smem_byte_offset).ir_value(loc=loc, ip=ip),
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row0).ir_value(loc=loc, ip=ip),
            Int32(row1).ir_value(loc=loc, ip=ip),
            Int32(row2).ir_value(loc=loc, ip=ip),
            Int32(row3).ir_value(loc=loc, ip=ip),
            mbar_ptr.toint().ir_value(loc=loc, ip=ip),
        ],
        "{\n"
        ".reg .u32 sa, ma;\n"
        "cvt.u32.u64 sa, $1;\n"
        "add.u32 sa, sa, $2;\n"
        "cvt.u32.u64 ma, $9;\n"
        "cp.async.bulk.tensor.2d.shared::cta.global.tile::gather4"
        ".mbarrier::complete_tx::bytes [sa], [$3, {$4, $5, $6, $7, $8}], [ma];\n"
        "mov.u32 $0, 0;\n"
        "}\n",
        "=r,l,r,l,r,r,r,r,r,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def prefetch_tma_desc_raw(tma_desc_ptr, *, loc=None, ip=None):
    """Prefetch a raw TMA descriptor pointer into the descriptor cache."""
    ptr_i64 = tma_desc_ptr.toint().ir_value(loc=loc, ip=ip)
    ptr_i64_align_ty = cute_ir.ConstrainedIntType.get(128, ptr_i64.type.width)
    ptr_i64_align = cute_ir.assume(ptr_i64_align_ty, ptr_i64, loc=loc, ip=ip)
    ptr_ty = cute_ir.PtrType.get(
        cute_nvgpu_ir.TmaDescriptorTiledType.get(),
        cute_ir.AddressSpace.gmem,
        128,
    )
    desc_ptr = cute_ir.inttoptr(ptr_ty, ptr_i64_align, loc=loc, ip=ip)
    cute_nvgpu_gen.arch_prefetch_tma_desc(desc_ptr.value, loc=loc, ip=ip)


@dsl_user_op
def tma_tile_prefetch(
    tma_desc_ptr,
    col_idx,
    row_idx,
    cache_hint=TMA_CACHE_EVICT_FIRST,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.prefetch.tensor.2d.L2.global.tile with cache hint."""
    llvm.inline_asm(
        None,
        [
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row_idx).ir_value(loc=loc, ip=ip),
            Int64(cache_hint).ir_value(loc=loc, ip=ip),
        ],
        "cp.async.bulk.prefetch.tensor.2d.L2.global.tile.L2::cache_hint "
        "[$0, {$1, $2}], $3;\n",
        "l,r,r,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def tma_gather4_prefetch(
    tma_desc_ptr,
    col_idx,
    row0,
    row1,
    row2,
    row3,
    cache_hint=TMA_CACHE_EVICT_LAST,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.prefetch.tensor.2d.L2.global.tile::gather4 with cache hint."""
    llvm.inline_asm(
        None,
        [
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row0).ir_value(loc=loc, ip=ip),
            Int32(row1).ir_value(loc=loc, ip=ip),
            Int32(row2).ir_value(loc=loc, ip=ip),
            Int32(row3).ir_value(loc=loc, ip=ip),
            Int64(cache_hint).ir_value(loc=loc, ip=ip),
        ],
        "cp.async.bulk.prefetch.tensor.2d.L2.global.tile::gather4.L2::cache_hint "
        "[$0, {$1, $2, $3, $4, $5}], $6;\n",
        "l,r,r,r,r,r,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def tma_tile_load_cached(
    smem_ptr,
    smem_byte_offset,
    tma_desc_ptr,
    col_idx,
    row_idx,
    mbar_ptr,
    cache_hint=TMA_CACHE_EVICT_FIRST,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.tensor.2d.shared::cta.global.tile with cache hint and mbar."""
    llvm.inline_asm(
        T.i32(),
        [
            smem_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(smem_byte_offset).ir_value(loc=loc, ip=ip),
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row_idx).ir_value(loc=loc, ip=ip),
            mbar_ptr.toint().ir_value(loc=loc, ip=ip),
            Int64(cache_hint).ir_value(loc=loc, ip=ip),
        ],
        "{\n"
        ".reg .u32 sa, ma;\n"
        "cvt.u32.u64 sa, $1;\n"
        "add.u32 sa, sa, $2;\n"
        "cvt.u32.u64 ma, $6;\n"
        "cp.async.bulk.tensor.2d.shared::cta.global.tile"
        ".mbarrier::complete_tx::bytes.L2::cache_hint "
        "[sa], [$3, {$4, $5}], [ma], $7;\n"
        "mov.u32 $0, 0;\n"
        "}\n",
        "=r,l,r,l,r,r,l,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def tma_gather4_cached(
    smem_ptr,
    smem_byte_offset,
    tma_desc_ptr,
    col_idx,
    row0,
    row1,
    row2,
    row3,
    mbar_ptr,
    cache_hint=TMA_CACHE_EVICT_LAST,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.tensor.2d.shared::cta.global.tile::gather4 with cache hint."""
    llvm.inline_asm(
        None,
        [
            smem_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(smem_byte_offset).ir_value(loc=loc, ip=ip),
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row0).ir_value(loc=loc, ip=ip),
            Int32(row1).ir_value(loc=loc, ip=ip),
            Int32(row2).ir_value(loc=loc, ip=ip),
            Int32(row3).ir_value(loc=loc, ip=ip),
            mbar_ptr.toint().ir_value(loc=loc, ip=ip),
            Int64(cache_hint).ir_value(loc=loc, ip=ip),
        ],
        "{\n"
        ".reg .u32 sa, ma;\n"
        "cvt.u32.u64 sa, $0;\n"
        "add.u32 sa, sa, $1;\n"
        "cvt.u32.u64 ma, $8;\n"
        "cp.async.bulk.tensor.2d.shared::cta.global.tile::gather4"
        ".mbarrier::complete_tx::bytes.cta_group::1.L2::cache_hint "
        "[sa], [$2, {$3, $4, $5, $6, $7}], [ma], $9;\n"
        "}\n",
        "l,r,l,r,r,r,r,r,l,l",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def tma_tile_store(
    tma_desc_ptr,
    col_idx,
    row_idx,
    smem_ptr,
    smem_byte_offset,
    *,
    loc=None,
    ip=None,
):
    """cp.async.bulk.tensor.2d.global.shared::cta.bulk_group store."""
    llvm.inline_asm(
        T.i32(),
        [
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(col_idx).ir_value(loc=loc, ip=ip),
            Int32(row_idx).ir_value(loc=loc, ip=ip),
            smem_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(smem_byte_offset).ir_value(loc=loc, ip=ip),
        ],
        "{\n"
        ".reg .u32 sa;\n"
        "cvt.u32.u64 sa, $4;\n"
        "add.u32 sa, sa, $5;\n"
        "cp.async.bulk.tensor.2d.global.shared::cta.bulk_group"
        " [$1, {$2, $3}], [sa];\n"
        "mov.u32 $0, 0;\n"
        "}\n",
        "=r,l,r,r,l,r",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


@dsl_user_op
def tma_tile_store_5d(
    tma_desc_ptr,
    coord0,
    coord1,
    coord2,
    coord3,
    coord4,
    smem_ptr,
    smem_byte_offset=0,
    *,
    loc=None,
    ip=None,
):
    """Issue one rank-5 TMA store from shared memory."""
    llvm.inline_asm(
        T.i32(),
        [
            tma_desc_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(coord0).ir_value(loc=loc, ip=ip),
            Int32(coord1).ir_value(loc=loc, ip=ip),
            Int32(coord2).ir_value(loc=loc, ip=ip),
            Int32(coord3).ir_value(loc=loc, ip=ip),
            Int32(coord4).ir_value(loc=loc, ip=ip),
            smem_ptr.toint().ir_value(loc=loc, ip=ip),
            Int32(smem_byte_offset).ir_value(loc=loc, ip=ip),
        ],
        "{\n"
        ".reg .u32 sa;\n"
        "cvt.u32.u64 sa, $7;\n"
        "add.u32 sa, sa, $8;\n"
        "cp.async.bulk.tensor.5d.global.shared::cta.bulk_group"
        " [$1, {$2, $3, $4, $5, $6}], [sa];\n"
        "mov.u32 $0, 0;\n"
        "}\n",
        "=r,l,r,r,r,r,r,l,r",
        has_side_effects=True,
        is_align_stack=False,
        asm_dialect=llvm.AsmDialect.AD_ATT,
        loc=loc,
        ip=ip,
    )


# Descriptor Builders

_TMA_DESC_BYTES = 128
_RAGGED_TMA_ROW_BOX = 128
_RAGGED_TMA_LARGE_N = 1 << 30
_RAGGED_TMA_XLARGE_STRIDE_BYTES = 1 << 36


def _encode_tma_desc_2d_bytes(tensor_2d, *, box_x, box_y, context: str) -> bytes:
    import torch
    import cuda.bindings.driver as cuda

    if tensor_2d.ndim != 2:
        raise ValueError(f"{context} tensor must be rank-2, got {tuple(tensor_2d.shape)}")
    rows, cols = tensor_2d.shape
    if tensor_2d.stride(-1) != 1:
        raise ValueError(f"{context} tensor must be contiguous in the last dimension")
    dtype_map = {
        torch.float16: cuda.CUtensorMapDataType.CU_TENSOR_MAP_DATA_TYPE_FLOAT16,
        torch.bfloat16: cuda.CUtensorMapDataType.CU_TENSOR_MAP_DATA_TYPE_BFLOAT16,
        torch.float8_e4m3fn: cuda.CUtensorMapDataType.CU_TENSOR_MAP_DATA_TYPE_UINT8,
    }
    if tensor_2d.dtype not in dtype_map:
        raise TypeError(f"Unsupported dtype for {context} TMA descriptor: {tensor_2d.dtype}")

    sizes = [cuda.cuuint64_t(cols), cuda.cuuint64_t(rows)]
    strides = [cuda.cuuint64_t(tensor_2d.stride(0) * tensor_2d.element_size())]
    box = [cuda.cuuint32_t(box_x), cuda.cuuint32_t(box_y)]
    elem_stride = [cuda.cuuint32_t(1), cuda.cuuint32_t(1)]
    err, tm = cuda.cuTensorMapEncodeTiled(
        dtype_map[tensor_2d.dtype],
        2,
        tensor_2d.data_ptr(),
        sizes,
        strides,
        box,
        elem_stride,
        cuda.CUtensorMapInterleave.CU_TENSOR_MAP_INTERLEAVE_NONE,
        cuda.CUtensorMapSwizzle.CU_TENSOR_MAP_SWIZZLE_128B,
        cuda.CUtensorMapL2promotion.CU_TENSOR_MAP_L2_PROMOTION_L2_256B,
        cuda.CUtensorMapFloatOOBfill.CU_TENSOR_MAP_FLOAT_OOB_FILL_NONE,
    )
    assert err == cuda.CUresult.CUDA_SUCCESS, f"TMA encode failed: {err}"
    buf = (ctypes.c_uint8 * _TMA_DESC_BYTES).from_address(tm.getPtr())
    return bytes(buf)


def _desc_bytes_to_device_tensor(desc_bytes: bytes | bytearray, *, device):
    import torch

    desc_bytes = bytes(desc_bytes)
    device = torch.device(device)
    if device.type != "cuda":
        raise ValueError(f"TMA descriptors require a CUDA device, got {device}")

    host_desc = torch.empty((len(desc_bytes),), dtype=torch.uint8, pin_memory=True)
    host_desc.copy_(torch.frombuffer(bytearray(desc_bytes), dtype=torch.uint8))
    device_desc = torch.empty((len(desc_bytes),), dtype=torch.uint8, device=device)
    stream = torch.cuda.current_stream(device)
    with torch.cuda.stream(stream):
        device_desc.copy_(host_desc, non_blocking=True)
    device_desc.record_stream(stream)
    # Keep the staging buffer alive for the async copy without caching descriptors.
    device_desc._tma_host_desc = host_desc
    return device_desc


def create_ragged_o_tma_desc(tensor_2d):
    """Create the synthetic-dimension BF16 descriptor used for ragged O tiles."""
    import torch
    import cuda.bindings.driver as cuda

    if tensor_2d.ndim != 2 or tensor_2d.dtype is not torch.bfloat16:
        raise TypeError("ragged O TMA requires a rank-2 BF16 tensor")
    rows, cols = tensor_2d.shape
    if cols != 128 or tensor_2d.stride(1) != 1 or tensor_2d.stride(0) != cols:
        raise ValueError("ragged O TMA requires contiguous [rows, 128] storage")
    if rows >= _RAGGED_TMA_LARGE_N:
        raise ValueError("ragged O TMA row coordinate exceeds the signed-I32 limit")

    row_stride = cols * tensor_2d.element_size()
    sizes = [
        cuda.cuuint64_t(cols),
        cuda.cuuint64_t(1),
        cuda.cuuint64_t(_RAGGED_TMA_ROW_BOX),
        cuda.cuuint64_t(1 << 31),
        cuda.cuuint64_t(1 << 31),
    ]
    strides = [
        cuda.cuuint64_t(row_stride),
        cuda.cuuint64_t(row_stride),
        cuda.cuuint64_t(_RAGGED_TMA_XLARGE_STRIDE_BYTES - row_stride),
        cuda.cuuint64_t(row_stride),
    ]
    box = [
        cuda.cuuint32_t(64),
        cuda.cuuint32_t(1),
        cuda.cuuint32_t(_RAGGED_TMA_ROW_BOX),
        cuda.cuuint32_t(1),
        cuda.cuuint32_t(1),
    ]
    elem_stride = [cuda.cuuint32_t(1) for _ in range(5)]
    err, tm = cuda.cuTensorMapEncodeTiled(
        cuda.CUtensorMapDataType.CU_TENSOR_MAP_DATA_TYPE_BFLOAT16,
        5,
        tensor_2d.data_ptr(),
        sizes,
        strides,
        box,
        elem_stride,
        cuda.CUtensorMapInterleave.CU_TENSOR_MAP_INTERLEAVE_NONE,
        cuda.CUtensorMapSwizzle.CU_TENSOR_MAP_SWIZZLE_128B,
        cuda.CUtensorMapL2promotion.CU_TENSOR_MAP_L2_PROMOTION_L2_256B,
        cuda.CUtensorMapFloatOOBfill.CU_TENSOR_MAP_FLOAT_OOB_FILL_NONE,
    )
    if err != cuda.CUresult.CUDA_SUCCESS:
        raise RuntimeError(f"ragged O TMA encode failed: {err}")
    buf = (ctypes.c_uint8 * _TMA_DESC_BYTES).from_address(tm.getPtr())
    return _desc_bytes_to_device_tensor(bytes(buf), device=tensor_2d.device)


def ragged_o_tma_coords(column, row, row_extent):
    """Preserve ``row`` while encoding the valid extent as TMA OOB rows."""
    box = Int32(_RAGGED_TMA_ROW_BOX)
    extent = Int32(row_extent)
    extent = cutlass.max(Int32(0), cutlass.min(box, extent))
    extent_mod = extent % box
    distance = box - extent_mod
    dimension_offset = distance % box
    dimension_offset += box * Int32(extent == Int32(0))
    large_n = Int32(_RAGGED_TMA_LARGE_N)
    return (
        Int32(column),
        Int32(0),
        dimension_offset,
        large_n,
        Int32(row) + large_n - dimension_offset,
    )


def create_flat_gather4_tma_desc(tensor_2d, box_x=64):
    """Create a gather4 CUtensorMap descriptor for a flat 2D row-major tensor."""
    if tensor_2d.ndim != 2:
        raise ValueError(
            f"tensor_2d must be rank-2 [rows, dim], got {tuple(tensor_2d.shape)}"
        )
    desc = _encode_tma_desc_2d_bytes(
        tensor_2d,
        box_x=box_x,
        box_y=1,
        context="gather4",
    )
    return _desc_bytes_to_device_tensor(desc, device=tensor_2d.device)


def create_q_gather4_tma_desc(q_flat, box_x=64):
    return create_flat_gather4_tma_desc(q_flat, box_x=box_x)


def create_strided_2d_tma_desc(tensor_2d, *, box_x, box_y):
    """Create a CUtensorMap descriptor for a rank-2 tensor with arbitrary row stride."""
    desc = _encode_tma_desc_2d_bytes(
        tensor_2d,
        box_x=box_x,
        box_y=box_y,
        context="strided 2D",
    )
    return _desc_bytes_to_device_tensor(desc, device=tensor_2d.device)


def create_flat_kv_tma_descs(kv_flat, *, box_x=64, box_y=128):
    """Create per-KV-head token-major TMA descriptors for flat [total_k, H, D] storage."""
    import torch

    if kv_flat.ndim != 3:
        raise ValueError(
            f"kv_flat must be rank-3 [total_k, H, D], got {tuple(kv_flat.shape)}"
        )
    total_k, head_kv, dim = kv_flat.shape
    row_stride = head_kv * dim
    desc_table = bytearray()
    for h in range(head_kv):
        head_view = torch.as_strided(
            kv_flat,
            size=(total_k, dim),
            stride=(row_stride, 1),
            storage_offset=h * dim,
        )
        desc_table.extend(
            _encode_tma_desc_2d_bytes(
                head_view,
                box_x=box_x,
                box_y=box_y,
                context="flat KV",
            )
        )
    return _desc_bytes_to_device_tensor(desc_table, device=kv_flat.device).reshape(
        head_kv, _TMA_DESC_BYTES
    )


# Compatibility Re-exports

from .copy_utils import (
    atomic_add_broadcast_i32,
    atomic_add_i32,
    convert_layout_acc_mn,
    convert_layout_from_tmem16x256b_to_acc_sm90,
    make_16x256b_tensor_mn_view,
    real_col_to_stg128_fake_col,
    real_col_to_stg128_fp8_fake_col,
    real_col_to_stg128_half_fake_col,
    stg128_fake_col_to_real_col,
    stg128_fp8_fake_col_to_real_col,
    stg128_half_fake_col_to_real_col,
    stg_128,
    stg_128_cs,
    stg_128_bf16,
    stg_128_bf16_cs,
    stg_128_f16,
    stg_128_f16_cs,
    stg_128_fp8_e4m3_cs,
    stg_32_fp8_e4m3,
    stg_64_bf16,
    stg_64_f16,
)


__all__ = [
    "TMA_CACHE_EVICT_FIRST",
    "TMA_CACHE_EVICT_LAST",
    "atomic_add_broadcast_i32",
    "atomic_add_i32",
    "convert_layout_acc_mn",
    "convert_layout_from_tmem16x256b_to_acc_sm90",
    "create_flat_gather4_tma_desc",
    "create_flat_kv_tma_descs",
    "create_q_gather4_tma_desc",
    "create_ragged_o_tma_desc",
    "create_strided_2d_tma_desc",
    "make_16x256b_tensor_mn_view",
    "prefetch_tma_desc_raw",
    "ragged_o_tma_coords",
    "real_col_to_stg128_fake_col",
    "real_col_to_stg128_fp8_fake_col",
    "real_col_to_stg128_half_fake_col",
    "stg128_fake_col_to_real_col",
    "stg128_fp8_fake_col_to_real_col",
    "stg128_half_fake_col_to_real_col",
    "stg_128",
    "stg_128_cs",
    "stg_128_bf16",
    "stg_128_bf16_cs",
    "stg_128_f16",
    "stg_128_f16_cs",
    "stg_128_fp8_e4m3_cs",
    "stg_32_fp8_e4m3",
    "stg_64_bf16",
    "stg_64_f16",
    "tma_gather4",
    "tma_gather4_cached",
    "tma_gather4_prefetch",
    "tma_tile_load",
    "tma_tile_load_cached",
    "tma_tile_prefetch",
    "tma_tile_store",
    "tma_tile_store_5d",
]
